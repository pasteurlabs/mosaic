# Copyright 2026 Pasteur Labs. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

"""Unit tests for trimmed_mean.

trimmed_mean computes the ensemble reference baseline that every solver's
error is measured against. These tests verify the two code paths (n<=2
plain mean, n>2 quantile trim) and boundary conditions.
"""

from __future__ import annotations

import jax.numpy as jnp
import pytest

from mosaic.benchmarks.core.utils import trimmed_mean


class TestTrimmedMean:
    def test_single_array_passthrough(self):
        a = jnp.array([1.0, 2.0, 3.0])
        result = trimmed_mean([a])
        assert jnp.allclose(result, a)

    def test_two_arrays_plain_mean(self):
        a = jnp.array([0.0, 4.0])
        b = jnp.array([2.0, 6.0])
        result = trimmed_mean([a, b])
        assert jnp.allclose(result, jnp.array([1.0, 5.0]))

    def test_three_or_more_trims_outlier(self):
        # 4 arrays where one is an extreme outlier. The trimmed mean
        # should give a result closer to the non-outlier values.
        normal = jnp.array([1.0, 1.0, 1.0])
        arrays = [normal, normal, normal, jnp.array([100.0, 100.0, 100.0])]
        result = trimmed_mean(arrays)
        plain = jnp.stack(arrays).mean(axis=0)
        # Trimmed result should be closer to 1.0 than the plain mean.
        assert float(jnp.abs(result - 1.0).max()) < float(jnp.abs(plain - 1.0).max())

    def test_identical_arrays(self):
        a = jnp.array([5.0, 10.0])
        result = trimmed_mean([a, a, a, a])
        assert jnp.allclose(result, a)

    def test_five_arrays_excludes_extreme(self):
        # With 5 arrays, the 5th and 95th percentile should bracket the
        # central values and exclude the min/max.
        arrays = [jnp.array([float(i)]) for i in [1, 2, 3, 4, 100]]
        result = trimmed_mean(arrays)
        # The outlier (100) should be trimmed; result should be < plain mean.
        plain = jnp.stack(arrays).mean(axis=0)
        assert float(result[0]) < float(plain[0])

    def test_near_identical_scalars_no_zero_collapse(self):
        # 4 near-identical scalars where quantile interpolation pushes the
        # lo/hi bracket outside all discrete values. Without the fallback
        # the mask is all-false and the result collapses to 0.
        arrays = [jnp.array(v) for v in [0.003665, 0.003665, 0.003681, 0.003665]]
        result = trimmed_mean(arrays)
        assert float(result) > 0.003, f"Expected ~0.00367, got {float(result)}"

    def test_empty_list_raises(self):
        with pytest.raises(ValueError):
            trimmed_mean([])


class TestTrimmedMeanNonFinite:
    """A solver that returns NaN must not take the reference down with it.

    The reference is what every solver's error is measured against, so a
    single non-finite entry propagating into it turns every other solver's
    error NaN and the whole cell reads as broken.
    """

    def test_nan_from_one_array_does_not_reach_the_result(self):
        healthy = [jnp.array([1.0, 2.0, 3.0]) + 0.01 * i for i in range(6)]
        result = trimmed_mean([*healthy, jnp.array([1.0, jnp.nan, 3.0])])
        assert bool(jnp.all(jnp.isfinite(result)))

    def test_inf_from_one_array_does_not_reach_the_result(self):
        healthy = [jnp.array([1.0, 2.0, 3.0]) + 0.01 * i for i in range(6)]
        result = trimmed_mean([*healthy, jnp.array([1.0, jnp.inf, 3.0])])
        assert bool(jnp.all(jnp.isfinite(result)))

    def test_an_all_nan_array_is_ignored_entirely(self):
        healthy = [jnp.array([1.0, 2.0, 3.0]) + 0.01 * i for i in range(6)]
        assert jnp.allclose(
            trimmed_mean([*healthy, jnp.full((3,), jnp.nan)]), trimmed_mean(healthy)
        )

    def test_two_arrays_use_the_finite_one(self):
        """The n <= 2 branch takes the same treatment as the quantile one."""
        result = trimmed_mean([jnp.array([1.0, 2.0]), jnp.array([jnp.nan, 4.0])])
        assert jnp.allclose(result, jnp.array([1.0, 3.0]))

    def test_position_where_nothing_is_finite_stays_nan(self):
        """No finite value to average is honestly NaN, not a silent zero."""
        result = trimmed_mean([jnp.array([1.0, jnp.nan, 3.0])] * 4)
        assert bool(jnp.isnan(result[1]))
        assert float(result[0]) == 1.0
        assert float(result[2]) == 3.0
