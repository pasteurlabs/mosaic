# Copyright 2026 Pasteur Labs. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

"""Tests for shared Tesseract schemas: domain schemas are importable and well-formed."""

from __future__ import annotations

from typing import ClassVar

import numpy as np
import pytest

# The schema modules import from ``mosaic_shared.schema_types`` and
# ``tesseract_core.runtime`` which are only available when these packages are
# installed (e.g. inside a tesseract runtime or a full dev environment).
_missing_runtime_deps = False
try:
    import mosaic_shared.schema_types  # noqa: F401
    import tesseract_core.runtime  # noqa: F401
except ModuleNotFoundError:
    _missing_runtime_deps = True

needs_runtime = pytest.mark.skipif(
    _missing_runtime_deps,
    reason="mosaic_shared / tesseract_core not installed as top-level packages",
)


@needs_runtime
@pytest.mark.parametrize(
    "module",
    [
        "mosaic.mosaic_shared.problems.navier_stokes_grid",
        "mosaic.mosaic_shared.problems.structural_mesh",
        "mosaic.mosaic_shared.problems.thermal_mesh",
    ],
)
def test_domain_schemas_define_input_and_output(module):
    """Each problem-schema module must expose populated InputSchema /
    OutputSchema. Catches a broken import or an accidentally emptied schema
    (pydantic happily accepts a zero-field model).
    """
    import importlib

    mod = importlib.import_module(module)
    for name in ("InputSchema", "OutputSchema"):
        cls = getattr(mod, name)
        assert cls.model_fields, f"{module}.{name} has no fields"


@needs_runtime
def test_ns_grid_input_declares_canonical_fields():
    """Catches a regression where the NS grid InputSchema loses its standard
    fields. The full canonical set was once silently emptied by a refactor.
    """
    from mosaic.mosaic_shared.problems.navier_stokes_grid import (
        InputSchema,
    )

    field_names = set(InputSchema.model_fields.keys())
    expected_subset = {
        "v0",
        "state",
        "return_state",
        "viscosity",
        "dt",
        "steps",
    }
    missing = expected_subset - field_names
    assert not missing, f"NS grid InputSchema lost canonical fields: {missing}"


@needs_runtime
def test_ns_grid_recurrent_state_is_canonical_but_opt_in():
    """The common schema names recurrent fields without enabling every solver."""
    from mosaic_shared.schema_types import make_differentiable

    from mosaic.mosaic_shared.problems.navier_stokes_grid import (
        InputSchema,
        OutputSchema,
    )

    default_inputs = InputSchema()
    assert default_inputs.state is None
    assert default_inputs.return_state is False
    assert OutputSchema(result=default_inputs.v0).state is None

    state = np.zeros((11, 8, 8, 1), dtype=np.float32)
    with pytest.raises(ValueError, match="does not opt in"):
        InputSchema(state=state)
    with pytest.raises(ValueError, match="does not opt in"):
        InputSchema(return_state=True)

    class RecurrentInputSchema(make_differentiable(InputSchema, ["state"])):
        supports_recurrent_state: ClassVar[bool] = True

    RecurrentOutputSchema = make_differentiable(OutputSchema, ["state"])
    continued = RecurrentInputSchema(state=state)
    requested = RecurrentInputSchema(return_state=True)
    output = RecurrentOutputSchema(result=continued.v0, state=state)
    np.testing.assert_array_equal(continued.state, state)
    np.testing.assert_array_equal(output.state, state)
    assert requested.return_state is True
    assert (
        RecurrentInputSchema.model_fields["state"].description
        == InputSchema.model_fields["state"].description
    )
    assert (
        RecurrentOutputSchema.model_fields["state"].description
        == OutputSchema.model_fields["state"].description
    )
