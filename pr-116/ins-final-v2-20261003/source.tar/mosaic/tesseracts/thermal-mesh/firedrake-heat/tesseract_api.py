# Copyright 2026 Pasteur Labs. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
# ruff: noqa: F405

"""Thermal heat conduction on an arbitrary hexahedral mesh.

Uses Firedrake + firedrake-adjoint to solve steady-state heat conduction with
SIMP material interpolation and a volumetric heat source, then compute the
exact adjoint gradient of both the thermal compliance and the source-identification
objectives.

CRITICAL import order: firedrake.adjoint must immediately follow firedrake so
that it can monkey-patch solve/assemble and record operations on the adjoint tape.
"""

import os
import tempfile
from typing import Any

import meshio
import numpy as np
from firedrake import *  # noqa: F403
from firedrake.adjoint import *  # noqa: F403
from mosaic_shared.problems.thermal_mesh import (
    InputSchema as _CanonicalInputSchema,
)
from mosaic_shared.problems.thermal_mesh import (
    OutputSchema as _CanonicalOutputSchema,
)
from mosaic_shared.schema_types import make_differentiable
from pydantic import Field
from scipy.spatial import cKDTree
from tesseract_core.runtime import ShapeDType

# ---------------------------------------------------------------------------
# Schema — extends canonical with material parameters
# ---------------------------------------------------------------------------


class InputSchema(make_differentiable(_CanonicalInputSchema, ["rho", "source"])):
    """Inputs for Firedrake thermal solver, extended with material parameters."""

    k_max: float = Field(
        default=1.0,
        description="Maximum thermal conductivity (fully solid/conducting material).",
    )
    p_exp: float = Field(
        default=3.0,
        description="SIMP penalisation exponent p (k(ρ) = k_min + (k_max−k_min)·ρ^p).",
    )


class OutputSchema(
    make_differentiable(
        _CanonicalOutputSchema, ["thermal_compliance", "identification_error"]
    )
):
    """Firedrake thermal solver output schema."""


# ---------------------------------------------------------------------------
# Mesh construction with tagged boundary groups  (reused from structural-mesh)
# ---------------------------------------------------------------------------


def _build_firedrake_mesh(
    pts: np.ndarray,
    cells: np.ndarray,
    dirichlet_mask: np.ndarray,
    neumann_mask: np.ndarray,
):
    """Convert numpy hex mesh arrays to a Firedrake Mesh via GMSH .msh file.

    Tag convention:
        Dirichlet group k → tag k
        Neumann group k   → tag 100 + k  (offset to avoid collision)
    """
    neumann_offset = 100

    hex_local_faces = [
        [0, 1, 2, 3],  # z-min
        [4, 5, 6, 7],  # z-max
        [0, 1, 5, 4],  # y-min
        [2, 3, 7, 6],  # y-max
        [0, 3, 7, 4],  # x-min
        [1, 2, 6, 5],  # x-max
    ]

    face_count: dict[tuple, int] = {}
    face_nodes: dict[tuple, tuple] = {}
    for cell in cells:
        for local_f in hex_local_faces:
            raw = tuple(int(cell[i]) for i in local_f)
            key = tuple(sorted(raw))
            face_count[key] = face_count.get(key, 0) + 1
            face_nodes[key] = raw

    boundary_quads: list[tuple] = []
    boundary_tags: list[int] = []

    for key, count in face_count.items():
        if count != 1:
            continue
        raw = face_nodes[key]
        d_groups = [int(dirichlet_mask[v]) for v in raw if v < len(dirichlet_mask)]
        n_groups_ = [int(neumann_mask[v]) for v in raw if v < len(neumann_mask)]
        d_uniq = set(d_groups)
        n_uniq = set(n_groups_)
        if len(d_uniq) == 1 and d_uniq != {0}:
            tag = next(iter(d_uniq))
        elif len(n_uniq) == 1 and n_uniq != {0}:
            tag = neumann_offset + next(iter(n_uniq))
        else:
            tag = 0
        boundary_quads.append(raw)
        boundary_tags.append(tag)

    if boundary_quads:
        boundary_arr = np.array(boundary_quads, dtype=np.int64)
        boundary_tag_arr = np.array(boundary_tags, dtype=np.int32)
        unique_tags = sorted(set(boundary_tags) - {0})
        extra_cells = []
        extra_phys: list[np.ndarray] = []
        for t in unique_tags:
            mask = boundary_tag_arr == t
            block_quads = boundary_arr[mask]
            n_block = int(mask.sum())
            extra_cells.append(("quad", block_quads))
            extra_phys.append(np.full(n_block, t, dtype=np.int32))
        mask0 = boundary_tag_arr == 0
        if mask0.any():
            extra_cells.append(("quad", boundary_arr[mask0]))
            extra_phys.append(np.zeros(int(mask0.sum()), dtype=np.int32))
        hex_phys = np.full(len(cells), 999, dtype=np.int32)
        phys_data = [hex_phys, *extra_phys]
        mio_mesh = meshio.Mesh(
            points=pts.astype(np.float64),
            cells=[("hexahedron", cells.astype(np.int64)), *extra_cells],
            cell_data={"gmsh:physical": phys_data},
        )
    else:
        mio_mesh = meshio.Mesh(
            points=pts.astype(np.float64),
            cells=[("hexahedron", cells.astype(np.int64))],
            cell_data={"gmsh:physical": [np.full(len(cells), 999, dtype=np.int32)]},
        )

    fd, msh_path = tempfile.mkstemp(suffix=".msh")
    os.close(fd)
    try:
        meshio.write(msh_path, mio_mesh, file_format="gmsh22")
        mesh = Mesh(msh_path)
    finally:
        if os.path.exists(msh_path):
            os.unlink(msh_path)

    # Record which Neumann tags were actually embedded in the mesh so that
    # callers can guard ds(tag) calls.  When the hot-spot stripe is narrower
    # than one mesh element (coarse debug runs), no face satisfies the
    # all-nodes-same-group criterion and the set will be empty — the caller
    # must skip those ds(tag) terms to avoid LookupError from Firedrake.
    active_neumann_tags: set[int] = set()
    for t in boundary_tags:
        if t >= neumann_offset:
            active_neumann_tags.add(t)

    return mesh, neumann_offset, active_neumann_tags


# ---------------------------------------------------------------------------
# Cell / node reorder maps  (Firedrake may renumber on load)
# ---------------------------------------------------------------------------


def _cell_reorder_map(
    pts: np.ndarray, input_cells: np.ndarray, fd_mesh: Any
) -> np.ndarray:
    """Build Firedrake-cell-index → input-cell-index permutation via centroid matching."""
    input_centroids = pts[input_cells].mean(axis=1)
    coord_arr = fd_mesh.coordinates.dat.data_ro
    cell_node_map = fd_mesh.coordinates.cell_node_map().values
    fd_centroids = coord_arr[cell_node_map].mean(axis=1)
    tree = cKDTree(input_centroids)
    _, fd_to_input = tree.query(fd_centroids)
    return fd_to_input


def _node_reorder_map(pts: np.ndarray, fd_mesh: Any) -> np.ndarray:
    """Build Firedrake-node-index → input-node-index permutation via coordinate matching."""
    fd_coords = fd_mesh.coordinates.dat.data_ro
    tree = cKDTree(pts)
    _, fd_to_input = tree.query(fd_coords)
    return fd_to_input


# ---------------------------------------------------------------------------
# Core solver
# ---------------------------------------------------------------------------


def _solve_heat(
    rho_values: np.ndarray,
    source_values: np.ndarray,
    pts: np.ndarray,
    cells: np.ndarray,
    dirichlet_mask_vals: np.ndarray,
    dirichlet_values_vals: np.ndarray,
    neumann_mask_vals: np.ndarray,
    neumann_values_vals: np.ndarray,
    k_max: float = 1.0,
    p_exp: float = 3.0,
    compute_gradient: bool = False,
    vjp_wrt_source: bool = False,
    target_temperature: np.ndarray | None = None,
    vjp_wrt_source_id_error: bool = False,
    vjp_rho_id_error: bool = False,
):
    """Solve 3-D steady-state heat conduction with SIMP + body source.

    Solves:
        -∇·(k(ρ) ∇T) = f    in Ω

    with SIMP conductivity:
        k(ρ) = k_min + (k_max − k_min) · ρ^p    (k_min = 1e-3·k_max)

    Thermal compliance:
        C = ∮_Γ_N q_n · T dΓ

    Identification error (optional):
        I = Σ_nodes (T - T_target)²   (source identification objective)

    Gradients:
        ∂C/∂ρ  via firedrake-adjoint ReducedFunctional (if compute_gradient)
        ∂C/∂f  via firedrake-adjoint ReducedFunctional (if vjp_wrt_source)
        ∂I/∂f  via a direct adjoint solve seeded with 2(T - T_target)
                (if vjp_wrt_source_id_error, requires target_temperature)
        ∂I/∂ρ  via the same adjoint solve (if vjp_rho_id_error,
                requires target_temperature)

    Returns:
        Tuple (J_val, T_nodes_input_order, dJ_drho, dJ_dsource, dI_dsource, dI_drho) where:
            J_val:              Scalar thermal compliance.
            T_nodes:            Temperature at input mesh nodes, shape (n_input_nodes,).
            dJ_drho:            Gradient ∂C/∂ρ, shape (n_cells,), or None.
            dJ_dsource:         Gradient ∂C/∂f, shape (n_cells,), or None.
            dI_dsource:         Gradient ∂I/∂f, shape (n_cells,), or None.
            dI_drho:            Gradient ∂I/∂ρ, shape (n_cells,), or None.
    """
    # Fresh tape for every solve.
    set_working_tape(Tape())
    continue_annotation()

    mesh, neumann_offset, active_neumann_tags = _build_firedrake_mesh(
        pts, cells, dirichlet_mask_vals, neumann_mask_vals
    )
    fd_to_input_cells = _cell_reorder_map(pts, cells, mesh)
    fd_to_input_nodes = _node_reorder_map(pts, mesh)

    V = FunctionSpace(mesh, "CG", 1)
    DG0 = FunctionSpace(mesh, "DG", 0)

    # ---- Density field (DG0) -------------------------------------------
    rho_fn = Function(DG0, name="rho")
    rho_reordered = np.clip(rho_values[fd_to_input_cells], 0.0, 1.0)
    rho_fn.dat.data[:] = rho_reordered

    # ---- Source field (DG0) --------------------------------------------
    source_fn = Function(DG0, name="source")
    src_reordered = np.zeros(mesh.num_cells(), dtype=np.float64)
    for fd_idx, inp_idx in enumerate(fd_to_input_cells):
        if inp_idx < len(source_values):
            src_reordered[fd_idx] = float(source_values[inp_idx])
    source_fn.dat.data[:] = src_reordered

    # ---- SIMP conductivity ---------------------------------------------
    k_min_val = Constant(1e-3 * k_max)
    k_field = k_min_val + (Constant(k_max) - k_min_val) * rho_fn ** Constant(p_exp)

    # ---- Neumann facet markers -----------------------------------------
    n_neumann_groups = neumann_values_vals.shape[0]
    # Build boundary measure from GMSH tags in the mesh.
    # ds: Firedrake will use the mesh tags; ds(tag) selects the tagged facets

    # ---- Variational problem -------------------------------------------
    T = TrialFunction(V)
    v = TestFunction(V)
    a = inner(k_field * grad(T), grad(v)) * dx

    # Neumann RHS — only include ds(tag) terms for tags that were actually
    # embedded in the mesh.  When the hot-spot stripe is too narrow for the
    # current mesh resolution (coarse debug runs), no boundary face satisfies
    # the all-nodes-same-group criterion and the tag will be absent from the
    # mesh.  Skipping those terms replicates FEniCS behaviour (empty integral
    # = 0) and prevents LookupError from Firedrake.
    L = inner(Constant(0.0), v) * dx
    for k in range(n_neumann_groups):
        tag = neumann_offset + (k + 1)
        if tag not in active_neumann_tags:
            continue
        q_n = Constant(float(neumann_values_vals[k, 0]))
        L = L + q_n * v * ds(tag)

    # Body heat source: ∫_Ω f · v dΩ
    L = L + source_fn * v * dx

    # ---- Dirichlet BCs -------------------------------------------------
    n_dirichlet_groups = dirichlet_values_vals.shape[0]
    bcs = []
    for k in range(n_dirichlet_groups):
        T_prescribed = Constant(float(dirichlet_values_vals[k, 0]))
        tag = k + 1
        bcs.append(DirichletBC(V, T_prescribed, tag))

    # ---- Solve ---------------------------------------------------------
    T_sol = Function(V)
    solve(a == L, T_sol, bcs)

    # ---- Thermal compliance --------------------------------------------
    J_form = inner(Constant(0.0), T_sol) * dx
    for k in range(n_neumann_groups):
        tag = neumann_offset + (k + 1)
        if tag not in active_neumann_tags:
            continue
        q_n = Constant(float(neumann_values_vals[k, 0]))
        J_form = J_form + q_n * T_sol * ds(tag)
    J = assemble(J_form)

    # ---- Extract temperature in input-node ordering --------------------
    T_fd = T_sol.dat.data_ro  # (n_fd_nodes,)
    input_to_fd = np.zeros(len(pts), dtype=np.int64)
    for fd_idx, inp_idx in enumerate(fd_to_input_nodes):
        input_to_fd[inp_idx] = fd_idx
    T_nodes = T_fd[input_to_fd]  # (n_input_nodes,)

    # ---- Gradients via adjoint -----------------------------------------
    dJ_drho = None
    dJ_dsource = None

    if compute_gradient:
        Jhat = ReducedFunctional(J, Control(rho_fn))
        dJ_fn = Jhat.derivative()
        dJ_fd = dJ_fn.dat.data_ro.copy()
        dJ_input = np.zeros(len(rho_values))
        for fd_idx, inp_idx in enumerate(fd_to_input_cells):
            dJ_input[inp_idx] = dJ_fd[fd_idx]
        dJ_drho = dJ_input

    if vjp_wrt_source:
        # Recompute with source as the control (separate ReducedFunctional).
        # Need a fresh tape for the source gradient.
        set_working_tape(Tape())
        continue_annotation()
        # Re-solve to record source → J on the new tape.
        rho_fn2 = Function(DG0, name="rho2")
        rho_fn2.dat.data[:] = rho_reordered
        source_fn2 = Function(DG0, name="source2")
        source_fn2.dat.data[:] = src_reordered
        k_field2 = k_min_val + (Constant(k_max) - k_min_val) * rho_fn2 ** Constant(
            p_exp
        )
        a2 = inner(k_field2 * grad(TrialFunction(V)), grad(TestFunction(V))) * dx
        L2 = inner(Constant(0.0), TestFunction(V)) * dx
        for k in range(n_neumann_groups):
            tag2 = neumann_offset + (k + 1)
            if tag2 not in active_neumann_tags:
                continue
            q_n2 = Constant(float(neumann_values_vals[k, 0]))
            L2 = L2 + q_n2 * TestFunction(V) * ds(tag2)
        L2 = L2 + source_fn2 * TestFunction(V) * dx
        T_sol2 = Function(V)
        solve(a2 == L2, T_sol2, bcs)
        J2_form = inner(Constant(0.0), T_sol2) * dx
        for k in range(n_neumann_groups):
            tag2 = neumann_offset + (k + 1)
            if tag2 not in active_neumann_tags:
                continue
            q_n2 = Constant(float(neumann_values_vals[k, 0]))
            J2_form = J2_form + q_n2 * T_sol2 * ds(tag2)
        J2 = assemble(J2_form)
        Jhat2 = ReducedFunctional(J2, Control(source_fn2))
        dJ_src_fn = Jhat2.derivative()
        dJ_src_fd = dJ_src_fn.dat.data_ro.copy()
        dJ_src_input = np.zeros(len(source_values))
        for fd_idx, inp_idx in enumerate(fd_to_input_cells):
            dJ_src_input[inp_idx] = dJ_src_fd[fd_idx]
        dJ_dsource = dJ_src_input

    dI_drho = None
    if vjp_rho_id_error and target_temperature is not None:
        # Map target_temperature (in input-node ordering) to firedrake node ordering.
        T_target_fd4 = Function(V)
        T_tgt4 = np.asarray(target_temperature, dtype=np.float64)
        T_tgt_reordered4 = np.zeros(mesh.num_vertices(), dtype=np.float64)
        for fd_idx, inp_idx in enumerate(fd_to_input_nodes):
            if inp_idx < len(T_tgt4):
                T_tgt_reordered4[fd_idx] = T_tgt4[inp_idx]
        T_target_fd4.dat.data[:] = T_tgt_reordered4
        with stop_annotating():
            adjoint_rhs4 = assemble(inner(Constant(0.0), TestFunction(V)) * dx)
            adjoint_rhs4.dat.data[:] = 2.0 * (
                T_sol.dat.data_ro - T_target_fd4.dat.data_ro
            )
            hom_bcs4 = [
                DirichletBC(V, Constant(0.0), k + 1) for k in range(n_dirichlet_groups)
            ]
            for bc in hom_bcs4:
                bc.zero(adjoint_rhs4)
            lam4 = Function(V)
            solve(assemble(a, bcs=hom_bcs4), lam4, adjoint_rhs4)
            dI_rho_fn = assemble(
                -derivative(k_field * inner(grad(T_sol), grad(lam4)) * dx, rho_fn)
            )
        dI_rho_vec = dI_rho_fn.dat.data_ro.copy()
        dI_rho_input = np.zeros(len(rho_values))
        dI_rho_input[fd_to_input_cells] = dI_rho_vec
        dI_drho = dI_rho_input

    dI_dsource = None
    if vjp_wrt_source_id_error and target_temperature is not None:
        # I = sum((T_nodes - T_target)²), so the adjoint is seeded with the
        # derivative of that, 2(T - T_target) at the nodes. The operator is
        # symmetric and the source enters the residual as source·v·dx, so
        #   A λ = 2(T - T_target),  homogeneous Dirichlet
        #   dI/ds_k = ∫_{cell k} λ dΩ
        # Prescribed nodes carry no sensitivity, so the seed is zeroed there.
        #
        # This is a hand-rolled adjoint, so it must not be annotated: annotation
        # is still on from the enclosing solve, and the low-level solve(A, x, b)
        # form is not tape-compatible — it makes firedrake build a SolveBlock
        # over the assembled operator and fail. stop_annotating keeps every
        # solve/assemble below off the tape.
        with stop_annotating():
            rho_fn3 = Function(DG0, name="rho3")
            rho_fn3.dat.data[:] = rho_reordered
            source_fn3 = Function(DG0, name="source3")
            source_fn3.dat.data[:] = src_reordered
            k_field3 = k_min_val + (Constant(k_max) - k_min_val) * rho_fn3 ** Constant(
                p_exp
            )
            a3 = inner(k_field3 * grad(TrialFunction(V)), grad(TestFunction(V))) * dx
            L3 = inner(Constant(0.0), TestFunction(V)) * dx
            for k in range(n_neumann_groups):
                tag3 = neumann_offset + (k + 1)
                if tag3 not in active_neumann_tags:
                    continue
                q_n3 = Constant(float(neumann_values_vals[k, 0]))
                L3 = L3 + q_n3 * TestFunction(V) * ds(tag3)
            L3 = L3 + source_fn3 * TestFunction(V) * dx
            T_sol3 = Function(V)
            solve(a3 == L3, T_sol3, bcs)
            # Map target_temperature (input-node ordering) to firedrake ordering.
            T_target_fd = Function(V)
            T_tgt = np.asarray(target_temperature, dtype=np.float64)
            T_tgt_reordered = np.zeros(mesh.num_vertices(), dtype=np.float64)
            for fd_idx, inp_idx in enumerate(fd_to_input_nodes):
                if inp_idx < len(T_tgt):
                    T_tgt_reordered[fd_idx] = T_tgt[inp_idx]
            T_target_fd.dat.data[:] = T_tgt_reordered
            adjoint_rhs = assemble(inner(Constant(0.0), TestFunction(V)) * dx)
            adjoint_rhs.dat.data[:] = 2.0 * (
                T_sol3.dat.data_ro - T_target_fd.dat.data_ro
            )
            hom_bcs = [
                DirichletBC(V, Constant(0.0), k + 1) for k in range(n_dirichlet_groups)
            ]
            for bc in hom_bcs:
                bc.zero(adjoint_rhs)
            lam = Function(V)
            solve(assemble(a3, bcs=hom_bcs), lam, adjoint_rhs)
            dI_src_fn = assemble(lam * TestFunction(DG0) * dx)
            dI_src_fd = dI_src_fn.dat.data_ro.copy()
            dI_src_input = np.zeros(len(source_values))
            for fd_idx, inp_idx in enumerate(fd_to_input_cells):
                dI_src_input[inp_idx] = dI_src_fd[fd_idx]
            dI_dsource = dI_src_input

    return float(J), T_nodes, dJ_drho, dJ_dsource, dI_dsource, dI_drho


# ---------------------------------------------------------------------------
# Tesseract endpoints
# ---------------------------------------------------------------------------


def apply(inputs: InputSchema) -> OutputSchema:
    """Forward pass: solve heat conduction and return compliance + identification error.

    Args:
        inputs: Validated InputSchema containing the density field, source,
                mesh, boundary conditions, and material parameters.

    Returns:
        OutputSchema with thermal_compliance (scalar) and identification_error (scalar).
    """
    hm = inputs.hex_mesh
    pts = np.asarray(hm.points[: hm.n_points], dtype=np.float64)
    cells = np.asarray(hm.faces[: hm.n_faces], dtype=np.int64)
    rho_values = np.asarray(inputs.rho[: hm.n_faces], dtype=np.float64)
    source_values = np.asarray(inputs.source[: hm.n_faces], dtype=np.float64)
    target_temp = np.asarray(inputs.target_temperature, dtype=np.float32)

    bc = inputs.boundary_conditions
    dm = np.asarray(bc.dirichlet.mask if bc.dirichlet else [])
    dv = np.asarray(
        bc.dirichlet.values
        if bc.dirichlet and bc.dirichlet.values is not None
        else np.zeros((0, 1)),
        dtype=np.float64,
    )
    vm = np.asarray(bc.neumann.mask if bc.neumann else [])
    vv = np.asarray(
        bc.neumann.values if bc.neumann else np.zeros((0, 1)), dtype=np.float64
    )

    J_val, T_nodes, _, _, _, _ = _solve_heat(
        rho_values,
        source_values,
        pts,
        cells,
        dm,
        dv,
        vm,
        vv,
        k_max=inputs.k_max,
        p_exp=inputs.p_exp,
        compute_gradient=False,
    )

    T_f32 = T_nodes.astype(np.float32)
    n = min(len(T_f32), len(target_temp))
    id_error = np.float32(np.sum((T_f32[:n] - target_temp[:n]) ** 2))

    return OutputSchema(
        thermal_compliance=np.float32(J_val),
        identification_error=id_error,
    )


def vector_jacobian_product(
    inputs: InputSchema,
    vjp_inputs: set[str],
    vjp_outputs: set[str],
    cotangent_vector: dict[str, Any],
) -> dict[str, Any]:
    """VJP via firedrake-adjoint: ∂C/∂ρ and ∂C/∂source scaled by cotangents.

    Supports differentiation through:
        rho    → thermal_compliance  (adjoint sensitivity ∂C/∂ρ)
        source → thermal_compliance  (adjoint sensitivity ∂C/∂f)

    Args:
        inputs: Validated InputSchema.
        vjp_inputs: Names of inputs for which gradients are requested.
        vjp_outputs: Names of outputs whose cotangents are provided.
        cotangent_vector: Dict of output-name → cotangent scalar/array.

    Returns:
        Dict with "rho" and/or "source" gradient arrays matching input shapes.
    """
    want_rho = "rho" in vjp_inputs
    want_source = "source" in vjp_inputs
    if not (want_rho or want_source):
        return {}

    hm = inputs.hex_mesh
    pts = np.asarray(hm.points[: hm.n_points], dtype=np.float64)
    cells = np.asarray(hm.faces[: hm.n_faces], dtype=np.int64)
    rho_values = np.asarray(inputs.rho[: hm.n_faces], dtype=np.float64)
    source_values = np.asarray(inputs.source[: hm.n_faces], dtype=np.float64)

    bc = inputs.boundary_conditions
    dm = np.asarray(bc.dirichlet.mask if bc.dirichlet else [])
    dv = np.asarray(
        bc.dirichlet.values
        if bc.dirichlet and bc.dirichlet.values is not None
        else np.zeros((0, 1)),
        dtype=np.float64,
    )
    vm = np.asarray(bc.neumann.mask if bc.neumann else [])
    vv = np.asarray(
        bc.neumann.values if bc.neumann else np.zeros((0, 1)), dtype=np.float64
    )

    # Determine which cotangent(s) to backpropagate.
    cot_compliance = float(cotangent_vector.get("thermal_compliance", 0.0))
    cot_id_error = float(cotangent_vector.get("identification_error", 0.0))
    want_source_compliance = want_source and cot_compliance != 0.0
    want_source_id_error = want_source and cot_id_error != 0.0
    want_rho_id_error = want_rho and cot_id_error != 0.0

    target_temp = np.asarray(inputs.target_temperature, dtype=np.float64)
    need_target = want_source_id_error or want_rho_id_error

    _, _, dJ_drho, dJ_dsource, dI_dsource, dI_drho = _solve_heat(
        rho_values,
        source_values,
        pts,
        cells,
        dm,
        dv,
        vm,
        vv,
        k_max=inputs.k_max,
        p_exp=inputs.p_exp,
        compute_gradient=want_rho and cot_compliance != 0.0,
        vjp_wrt_source=want_source_compliance,
        target_temperature=target_temp if need_target else None,
        vjp_wrt_source_id_error=want_source_id_error,
        vjp_rho_id_error=want_rho_id_error,
    )

    result: dict[str, Any] = {}

    if want_rho:
        grad_rho = np.zeros(len(np.asarray(inputs.rho)), dtype=np.float32)
        if dJ_drho is not None and cot_compliance != 0.0:
            grad_rho[: hm.n_faces] += (dJ_drho * cot_compliance).astype(np.float32)
        if dI_drho is not None and cot_id_error != 0.0:
            grad_rho[: hm.n_faces] += (dI_drho * cot_id_error).astype(np.float32)
        result["rho"] = grad_rho

    if want_source:
        grad_source = np.zeros(len(np.asarray(inputs.source)), dtype=np.float32)
        # Add compliance contribution
        if dJ_dsource is not None and cot_compliance != 0.0:
            grad_source[: hm.n_faces] += (dJ_dsource * cot_compliance).astype(
                np.float32
            )
        # Add identification_error contribution
        if dI_dsource is not None and cot_id_error != 0.0:
            grad_source[: hm.n_faces] += (dI_dsource * cot_id_error).astype(np.float32)
        result["source"] = grad_source

    return result


def abstract_eval(abstract_inputs: InputSchema) -> dict:
    """Shape inference without running the solver."""
    return {
        "thermal_compliance": ShapeDType(shape=(), dtype="float32"),
        "identification_error": ShapeDType(shape=(), dtype="float32"),
    }
