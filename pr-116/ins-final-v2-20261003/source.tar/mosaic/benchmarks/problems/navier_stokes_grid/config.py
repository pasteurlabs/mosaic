# Copyright 2026 Pasteur Labs. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

"""2D incompressible Navier-Stokes on a periodic grid.

The problem definition is split across these modules:

- :mod:`.ics`          — IC generators and the ``_tgv_analytic`` reference.
- :mod:`.physics`      — input factory (``make_inputs``); ``DIAGNOSTICS`` is
                         re-exported from
                         :mod:`mosaic.benchmarks.problems.shared.diagnostics`.
- :mod:`.optimization` — drag-minimisation runner.
- :mod:`.solver_in_loop` — neural corrector training through each solver.
- :mod:`.plots`        — per-experiment plot fns wired in below.
- :mod:`.exclusions`   — per-(solver, experiment) opt-outs.
- :mod:`.extras`       — cross-experiment aggregator plots.

This module performs solver discovery, the canonical :class:`Problem`
assembly, and the per-suite ``problem.add_experiment(...)`` calls with
inline plot descriptions, status checks, and per-experiment exclusions.
"""

from __future__ import annotations

import jax.numpy as jnp

from mosaic.benchmarks.core.config import (
    Problem,
    SolverSpec,
    discover_solvers,
)
from mosaic.benchmarks.core.status_checks import (
    max_error,
    max_final_ratio,
    max_peer_k,
    max_rel_err,
    median_k,
    min_cosine,
    rel_err_peer_outlier,
)
from mosaic.benchmarks.core.utils import l2_error_rel
from mosaic.benchmarks.problems.shared.cost import (
    spatial_cost,
    temporal_cost,
    vjp_cost,
)
from mosaic.benchmarks.problems.shared.forward import agreement, physical_laws
from mosaic.benchmarks.problems.shared.gradient import (
    fd_check,
    jacobian_svd,
    param_sweep,
)
from mosaic.benchmarks.problems.shared.plots.cost import plot_cost
from mosaic.benchmarks.problems.shared.plots.forward import (
    plot_agreement,
    plot_forward_fields,
    plot_physical_laws,
)
from mosaic.benchmarks.problems.shared.plots.gradient import (
    plot_fd_check,
    plot_horizon_sweep,
    plot_jacobian_svd_comparison,
    plot_param_sweep,
)
from mosaic.benchmarks.problems.shared.plots.ics import plot_ic
from mosaic.benchmarks.problems.shared.plots.solver_styles import apply_styles

from .exclusions import register as _register_exclusions
from .ics import _flat_inflow, _multimode, _tgv, _tgv_analytic, _uniform_flow
from .optimization import drag_opt
from .physics import DIAGNOSTICS, make_inputs
from .plots import (
    plot_drag_opt,
    plot_solver_in_loop,
    plot_solver_in_loop_reference_sensitivity,
    plot_solver_in_loop_self_reference,
    plot_solver_in_loop_supervised,
    plot_solver_in_loop_tgv,
)
from .solver_in_loop import solver_in_loop

_TESSERACT_SLUG = "navier-stokes-grid"


# ── Solver registry ──────────────────────────────────────────────────────────
# Per-solver fields (name, scheme, color, AD strategy, …) live in each
# tesseract's ``tesseract_config.yaml`` under ``metadata.mosaic``.
# Only per-(solver, problem) overrides (input_overrides / exclusions) are
# applied here.

_SOLVERS: dict[str, SolverSpec] = discover_solvers(_TESSERACT_SLUG)

# Exponax is a 3D-only spectral solver; exclude it from the 2D suite.
_SOLVERS.pop("exponax", None)

# Plot styling lives in mosaic.benchmarks.problems.shared.plots.solver_styles, not in YAML.
apply_styles(_SOLVERS)


_SOLVERS["jax_cfd"].input_overrides = {
    "density": jnp.array([1.0], dtype=jnp.float32),
    "inner_steps": 1,
}


# ── Problem assembly ─────────────────────────────────────────────────────────

problem = Problem(
    name="ns-grid",
    category_label="Navier–Stokes (Grid)",
    description=(
        "**Fluid flow in 2D.** We simulate an incompressible fluid (think of stirred "
        "water) and differentiate through the simulation. The headline question is "
        "whether each solver returns a trustworthy gradient as the flow becomes chaotic.\n\n"
        "Formally, we solve the 2D incompressible Navier–Stokes equations "
        "$\\partial_t \\mathbf{u} + (\\mathbf{u}\\cdot\\nabla)\\mathbf{u} "
        "= -\\nabla p + \\nu\\,\\nabla^2\\mathbf{u}$, $\\nabla\\cdot\\mathbf{u}=0$, "
        "with the kinematic viscosity $\\nu$ as the primary control parameter. The "
        "nonlinear advection term $\\nabla\\cdot(\\mathbf{u}\\otimes\\mathbf{u})$ "
        "transfers energy across scales; at low $\\nu$ the flow develops turbulent "
        "cascades and a positive Lyapunov exponent, so long-horizon gradients grow "
        "exponentially sensitive to perturbations. This is the regime where "
        "backprop-through-simulation is hardest."
    ),
    bc_description=(
        "Doubly-periodic square domain $[0, 2\\pi]^2$ (the flow wraps around at every "
        "edge). Incompressibility $\\nabla\\cdot\\mathbf{u}=0$ is enforced by a "
        "pressure projection at each time step. No walls or inflow/outflow boundaries."
    ),
    tesseract_dir=_TESSERACT_SLUG,
    output_key="result",
    ic_key="v0",
    solvers=list(_SOLVERS.values()),
    make_inputs=make_inputs,
    error_fn=l2_error_rel,
    reference=_tgv_analytic,
    domain_extent=2 * float(jnp.pi),
    status_checks={
        # Suite-level defaults — apply to every `<suite>/*` experiment unless
        # overridden by an inline `status_check=` on the `.add_experiment()` call.
        "forward": [median_k(3.0), max_error(0.5)],
        "cost": [max_peer_k(20.0)],
        "optimization": [max_final_ratio(0.5)],
        # multimode has no closed form, so it scores against the consensus;
        # an absolute bound on the distance to that says nothing about accuracy.
        "forward/agreement/multimode": [median_k(3.0)],
    },
)


# ── Initial conditions ───────────────────────────────────────────────────────
problem.add_ic(
    "multimode",
    fn=_multimode,
    description=(
        "Incompressible velocity field with energy concentrated in a ring at "
        "wavenumber $k=2$ ($\\sigma_k=0.5$); supports multi-scale turbulent development."
    ),
    plot_params={"N": 64},
    plot=plot_ic,
)
problem.add_ic(
    "tgv",
    fn=_tgv,
    description=(
        "Taylor–Green vortex $u=\\sin(x)\\cos(y)$, $v=-\\cos(x)\\sin(y)$; has a closed-form "
        "analytic solution for viscous decay, enabling solver verification."
    ),
    plot_params={"N": 64},
    plot=plot_ic,
)
problem.add_ic(
    "uniform",
    fn=_uniform_flow,
    description=(
        "Uniform rightward flow $u=(U, 0)$ — background flow for cylinder-wake "
        "(Kármán vortex street) experiments. Obstacle specified separately via "
        "the physics.obstacle field."
    ),
    plot_params={"N": 64, "U": 1.0},
    plot=plot_ic,
)
problem.add_ic(
    "flat_inflow",
    fn=_flat_inflow,
    description=(
        "Flat 1-D inlet velocity profile $u_x(y) = U$, shape (N,). "
        "Starting point for inflow-profile drag-optimisation experiments."
    ),
    plot_params={"N": 64, "U": 0.5},
    plot=plot_ic,
)


# ── Experiment registrations ─────────────────────────────────────────────────

# Forward
problem.add_experiment(
    "forward/baseline",
    agreement,
    plot_description=(
        "Relative error vs grid resolution $N$ at steps=1; validates single-step forward"
        " accuracy across solvers."
    ),
    ic={"name": "tgv", "seed": 0},
    physics={
        "N": [16, 32, 64, 128],
        "nu": 0.05,
        "dt": 0.01,
        "steps": 1,
        "lbm_N_base": 64,
    },
    plot=plot_agreement,
)
problem.add_experiment(
    "forward/agreement",
    agreement,
    plot_description=(
        "Relative error vs viscosity $\\nu$ for each IC, with vorticity field"
        " snapshots. The tgv variant is scored against the analytic TGV"
        " solution; multimode has no closed form and is scored against the"
        " cross-solver consensus."
    ),
    runs=[
        {
            "name": "tgv",
            "ic": {"name": "tgv", "seed": 42},
            "physics": {
                "N": 64,
                "dt": 0.05,
                "steps": 20,
                "nu": [0.001, 0.005, 0.01, 0.02, 0.05],
            },
        },
        {
            "name": "multimode",
            "ic": {"name": "multimode", "seed": 42},
            "physics": {
                "N": 64,
                "dt": 0.05,
                "steps": 20,
                "nu": [0.001, 0.005, 0.01, 0.02, 0.05],
            },
            "reference": "consensus",
        },
    ],
    plot=plot_agreement,
)
problem.add_experiment(
    "forward/tgv_nu_sweep",
    agreement,
    plot_description="Relative error vs viscosity $\\nu$ for each solver at a fixed TGV initial condition.",
    ic={"name": "tgv", "seed": 42},
    physics={
        "N": 64,
        "dt": 0.05,
        "steps": 20,
        "nu": [1e-4, 5e-4, 1e-3, 5e-3, 1e-2, 5e-2],
    },
    plot=plot_agreement,
)
problem.add_experiment(
    "forward/physical_laws",
    physical_laws,
    plot_description="Divergence RMS, kinetic energy, and analytic error vs $N$, steps, and $\\nu$ for each solver.",
    diagnostics=DIAGNOSTICS,
    runs=[
        {
            "name": "vs_N",
            "ic": {"name": "tgv", "seed": 0},
            "physics": {"nu": 0.05, "dt": 0.01, "steps": 20, "N": [16, 32, 64, 128]},
        },
        {
            "name": "vs_steps",
            "ic": {"name": "tgv", "seed": 0},
            "physics": {"nu": 0.05, "dt": 0.01, "N": 64, "steps": [5, 10, 20, 50, 100]},
        },
        {
            "name": "vs_nu",
            "ic": {"name": "tgv", "seed": 0},
            "physics": {
                "dt": 0.01,
                "steps": 20,
                "N": 64,
                "nu": [0.001, 0.005, 0.01, 0.05, 0.1],
            },
        },
    ],
    plot=plot_physical_laws,
)
problem.add_experiment(
    "forward/cylinder",
    agreement,
    plot_description=(
        "Vorticity snapshots and kinetic-energy evolution vs time for each solver"
        " across a sweep of viscosities."
    ),
    ic={"name": "uniform", "seed": 0},
    physics={
        "N": 64,
        "dt": 0.01,
        "steps": 500,
        "obstacle": {
            "shape": "cylinder",
            "center": [0.5, 0.5],
            "radius": 0.1,
        },
        "nu": [0.05, 0.02, 0.01, 0.005],
    },
    reference_solver="openfoam",
    plot=plot_forward_fields,
    status_check=[median_k(50.0), max_error(0.5)],
)
# Cost
problem.add_experiment(
    "cost/spatial_cost",
    spatial_cost,
    plot_description="Forward-pass wall-clock time vs grid resolution $N$ at fixed step count for all solvers.",
    physics={"nu": 0.01, "dt": 0.01, "steps": 100, "N": [64, 128, 192, 256]},
    cost={"n_trials": 3},
    plot=plot_cost,
)
problem.add_experiment(
    "cost/temporal_cost",
    temporal_cost,
    plot_description="Forward-pass wall-clock time vs step count at fixed $N$ for all solvers.",
    physics={"nu": 0.01, "dt": 0.01, "N": 128, "steps": [10, 50, 100, 500, 1000]},
    cost={"n_trials": 3},
    plot=plot_cost,
)
problem.add_experiment(
    "cost/vjp_cost",
    vjp_cost,
    plot_description="VJP wall-clock time vs $N$ and step count for differentiable solvers.",
    runs=[
        {
            "name": "by_N",
            "physics": {"nu": 0.01, "dt": 0.01, "steps": 100, "N": [64, 128, 192, 256]},
            "cost": {"n_trials": 3},
        },
        {
            "name": "by_steps",
            "physics": {
                "nu": 0.01,
                "dt": 0.01,
                "N": 128,
                "steps": [10, 50, 100, 500, 1000],
            },
            "cost": {"n_trials": 3},
        },
    ],
    plot=plot_cost,
)
# Gradient
problem.add_experiment(
    "gradient/fd_check",
    fd_check,
    plot_description=(
        "U-curves of finite-difference gradient error vs perturbation size $\\varepsilon$ together"
        " with subspace cosine; validates VJP correctness."
    ),
    ic={"name": "multimode", "seed": 42},
    physics={"N": 16, "nu": 0.001, "dt": 0.05, "steps": 20},
    fd={"eps_values": [5e0, 1e0, 1e-1, 1e-2, 1e-3, 1e-4], "n_dirs": 20},
    plot=plot_fd_check,
    status_check=[
        min_cosine(0.99),
        max_rel_err(1e-3),
        rel_err_peer_outlier(50.0),
    ],
)
problem.add_experiment(
    "gradient/param_sweep",
    param_sweep,
    plot_description=(
        "Gradient norm, best-$\\varepsilon$ FD error, direction cosine, and "
        "U-curves vs the sweep parameter."
    ),
    ic={"name": "multimode", "seed": 42},
    physics={"N": 16, "dt": 0.05, "steps": 200, "nu": [0.05, 0.01, 0.005, 0.001]},
    fd={"eps_values": [5e0, 1e0, 1e-1, 1e-2, 1e-3], "n_dirs": 15},
    plot=plot_param_sweep,
)
problem.add_experiment(
    "gradient/horizon_sweep",
    param_sweep,
    plot_description="Gradient norm, FD error, and direction cosine vs rollout horizon $T = \\mathrm{steps}\\cdot dt$.",
    ic={"name": "multimode", "seed": 42},
    physics={"N": 16, "nu": 0.001, "dt": 0.05, "steps": [5, 10, 20, 40, 80, 160, 320]},
    fd={"eps_values": [1e0, 1e-1, 1e-2, 1e-3], "n_dirs": 8},
    plot=plot_horizon_sweep,
)
problem.add_experiment(
    "gradient/jacobian_svd",
    jacobian_svd,
    plot_description="Singular-value spectrum and pairwise cross-solver cosine similarity of gradient subspaces.",
    ic={"name": "multimode", "seed": 42},
    physics={"N": 8, "nu": 0.001, "dt": 0.05, "steps": 10},
)
problem.add_experiment(
    "gradient/jacobian_svd_steps20",
    jacobian_svd,
    plot_description=(
        "Singular-value spectrum and pairwise cross-solver cosine similarity of"
        " gradient subspaces at an extended rollout horizon."
    ),
    ic={"name": "multimode", "seed": 42},
    physics={"N": 8, "nu": 0.001, "dt": 0.05, "steps": 20},
)
problem.add_experiment(
    "gradient/jacobian_svd_steps40",
    jacobian_svd,
    plot_description=(
        "Singular-value spectrum and pairwise cross-solver cosine similarity of"
        " gradient subspaces at a long rollout horizon."
    ),
    ic={"name": "multimode", "seed": 42},
    physics={"N": 8, "nu": 0.001, "dt": 0.05, "steps": 40},
)
problem.add_experiment(
    "gradient/jacobian_svd_nu01",
    jacobian_svd,
    plot_description=(
        "Singular-value spectrum and pairwise cross-solver cosine similarity of"
        " gradient subspaces at higher viscosity."
    ),
    ic={"name": "multimode", "seed": 42},
    physics={"N": 8, "nu": 0.01, "dt": 0.05, "steps": 10},
)

# Optimization
problem.add_experiment(
    "optimization/drag_opt",
    drag_opt,
    plot_description=(
        "Drag convergence curves per solver, optimised vs initial inflow profiles,"
        " and final drag coefficient comparison."
    ),
    ic={"name": "flat_inflow", "seed": 0},
    physics={
        # Re = U·D/ν = 0.5·0.1/0.0025 = 20
        # N=32 used (not 64): IBM hard-masking in jax-cfd causes pressure
        # projection divergence at N=64 (discontinuity at obstacle boundary
        # overwhelms the periodic Poisson solve at step ~20).
        # steps=200 (was 400): at dt=0.02 with U_mean=0.5 in a unit domain,
        # one flow-through is ~100 steps. 200 steps = 2 flow-throughs, with
        # the drag tail-window mean averaging over the last 100 steps — long
        # enough to wash out residual transients at Re=20 (no vortex
        # shedding). Halves the forward/backward solver wall per opt iter.
        "N": 32,
        "nu": 0.0025,
        "dt": 0.02,
        "steps": 200,
        "domain_extent": 1.0,
        "U_mean": 0.5,
        "obstacle": {
            "shape": "cylinder",
            "center": [0.5, 0.5],
            "radius": 0.05,
        },
    },
    optim={
        "lr": 5e-4,
        # max_iters=250 keeps the GPU runner under the 6h CI budget; Adam
        # doesn't converge within either budget here, so 250 just truncates a
        # non-converging tail.
        "max_iters": 250,
        "patience": 50,
        "flow_penalty_weight": 50.0,
        "snap_interval": 20,
    },
    plot=plot_drag_opt,
)
problem.add_experiment(
    "optimization/solver_in_loop",
    solver_in_loop,
    description=(
        "Train an identical Equinox periodic residual corrector through each "
        "differentiable solver. A solver-terminal recurrent auxiliary, paired "
        "stop-gradient controls, native versus repeated-call rollouts, and seen versus "
        "held-out IC horizons separate integration, coupling, trainability, and "
        "the incremental benefit of the solver VJP."
    ),
    plot_description=(
        "Corrector training, held-out trajectories, physical diagnostics, "
        "recurrent-call closure, correction gain, solver-VJP lift, and wall-clock "
        "cost for each differentiable solver."
    ),
    # Keep dataset seed lists inside an explicit run payload: they are data,
    # not benchmark sweep coordinates.
    runs=[
        {
            "ic": {"name": "multimode", "seed": 0},
            "physics": {
                # ``steps`` is the number of native PDE steps between neural
                # corrections. Recurrent training feeds back the corrected
                # canonical ``v0`` while preserving any solver-native checkpoint.
                "N": 32,
                "nu": 0.001,
                "dt": 0.02,
                "steps": 4,
            },
            "dataset": {
                "reference_kind": "pseudo_spectral_multimode",
                "reference_factor": 2,
                "reference_substeps": 2,
                "train_seeds": list(range(16)),
                "test_seeds": list(range(100, 108)),
                "train_frames": 24,
                # Begin from the well-resolved spectrum used by the forward
                # agreement benchmark. The stronger amplitude and long horizon
                # still allow nonlinear transfer to populate smaller scales.
                "k0": 2.0,
                "sigma_k": 0.5,
                "amplitude": 0.5,
            },
            "training": {
                "max_updates": 200,
                "unroll": 8,
                # A solver-only terminal auxiliary measures temporal credit
                # without letting it destabilize the locally supervised rollout.
                "loss_mode": "solver_terminal",
                "solver_loss_weight": 0.1,
                # Scale each solver's loss by its own uncorrected recurrent
                # baseline so clipping/optimisation do not inherit raw accuracy.
                "loss_normalization": "solver_baseline",
                "loss_scale_floor": 1e-6,
                "lr": 1e-4,
                "clip_norm": 5.0,
                "architecture": "periodic_residual_cnn",
                "hidden_channels": 32,
                "kernel_size": 5,
                "seed": 2026,
                "model_seeds": [0, 1, 2],
                "check_grad": True,
                "fd_epsilon": 1e-2,
            },
            "evaluation": {
                "rollout_frames": 36,
                "seen_ic_trajectories": 8,
                "stable_error_threshold": 1.0,
                # Predeclare forward-admission bounds for the nonlinear task.
                # Long chaotic trajectories may decorrelate, but a candidate
                # must start close to the common reference and remain finite
                # enough for a meaningful relative-gain comparison.
                "first_interval_error_tolerance": 0.05,
                "native_long_error_tolerance": 0.5,
            },
        }
    ],
    plot=plot_solver_in_loop,
)


def _reference_sensitivity_run(name: str, reference_kind: str) -> dict:
    """Return one common-target solver-loop reference variant."""
    return {
        "name": name,
        "ic": {"name": "multimode", "seed": 0},
        "physics": {
            "N": 32,
            "nu": 0.001,
            "dt": 0.02,
            "steps": 4,
        },
        "dataset": {
            "reference_kind": reference_kind,
            # Production targets use 128² and dt/4. A disjoint convergence
            # audit compares selected frames against 256² and dt/8 before
            # corrector training is admitted.
            "reference_factor": 4,
            "reference_substeps": 4,
            "reference_audit_factor": 8,
            "reference_audit_substeps": 8,
            "reference_audit_seeds": [0, 100],
            "reference_audit_frames": [1, 8, 24, 36],
            "reference_convergence_tolerance": 0.005,
            "train_seeds": list(range(16)),
            "test_seeds": list(range(100, 108)),
            "train_frames": 24,
            "k0": 2.0,
            "sigma_k": 0.5,
            "amplitude": 0.5,
        },
        "training": {
            "max_updates": 200,
            "unroll": 8,
            "loss_mode": "solver_terminal",
            "solver_loss_weight": 0.1,
            "loss_normalization": "solver_baseline",
            "loss_scale_floor": 1e-6,
            "lr": 1e-4,
            "clip_norm": 5.0,
            "architecture": "periodic_residual_cnn",
            "hidden_channels": 32,
            "kernel_size": 5,
            "seed": 2026,
            "model_seeds": [0, 1, 2],
            "check_grad": True,
            "fd_epsilon": 1e-2,
        },
        "evaluation": {
            "rollout_frames": 36,
            "seen_ic_trajectories": 8,
            "stable_error_threshold": 1.0,
            "first_interval_error_tolerance": 0.05,
            "native_long_error_tolerance": 0.5,
        },
    }


def _supervised_comparison_run() -> dict:
    """Declare a matched three-arm experiment on interacting periodic vortices."""
    run = _reference_sensitivity_run("supervised", "solver_self_refined")
    run.pop("name")
    run["physics"]["N"] = 64
    dataset = run["dataset"]
    dataset["reference_temporal_factor"] = dataset.pop("reference_substeps")
    dataset["reference_audit_temporal_factor"] = dataset.pop("reference_audit_substeps")
    dataset.update(
        {
            "k0": 4.0,
            "sigma_k": 1.0,
            "reference_factor": 3,
            "reference_temporal_factor": 3,
            "reference_audit_factor": 3,
            "reference_audit_temporal_factor": 6,
            "prefix_audit_seeds": [0, 100],
            "prefix_audit_frames": [1, 8, 24, 36],
        }
    )
    run["training"].update(
        {
            "max_updates": 3000,
            "loss_mode": "mean",
            "solver_loss_weight": 0.0,
            "include_supervised_baseline": True,
        }
    )
    return run


problem.add_experiment(
    "optimization/solver_in_loop_supervised",
    solver_in_loop,
    description=(
        "Test whether differentiating through a solver produces a useful corrector "
        "beyond fixed-pair supervised training and stopped-gradient recurrent training. "
        "Each solver learns against its own spatially and temporally refined reference. "
        "The fixed 192² reference for a 64² coarse grid is checked in time, not certified spatially converged. "
        "All arms share initial weights, training windows and optimizer updates; "
        "evaluation uses held-out free-running trajectories."
    ),
    plot_description=(
        "Held-out rollout errors for supervised, stopped-gradient, full-gradient "
        "and uncorrected solvers. Training and supervised preprocessing costs are "
        "reported separately; superiority is a hypothesis, not an admission rule."
    ),
    runs=[_supervised_comparison_run()],
    plot=plot_solver_in_loop_supervised,
)


problem.add_experiment(
    "optimization/solver_in_loop_reference_sensitivity",
    solver_in_loop,
    description=(
        "Repeat the common all-solver corrector comparison against independently "
        "discretized, space-time-converged pseudo-spectral and conservative "
        "finite-volume references. Paired VJP conclusions are reported separately "
        "from reference-dependent absolute error."
    ),
    plot_description=(
        "Reference disagreement, convergence audits, absolute error, correction "
        "gain, and paired solver-VJP lift under spectral and finite-volume targets."
    ),
    runs=[
        _reference_sensitivity_run("spectral", "pseudo_spectral_multimode"),
        _reference_sensitivity_run("finite_volume", "finite_volume_multimode"),
    ],
    plot=plot_solver_in_loop_reference_sensitivity,
)

problem.add_experiment(
    "optimization/solver_in_loop_tgv",
    solver_in_loop,
    description=(
        "Run an all-solver solver-in-the-loop control using the analytic N=64 "
        "forward/baseline case, with an explicit Mach-safe XLB substep budget so "
        "every differentiable solver passes both one-interval and uninterrupted "
        "forward gates. Repeated calls then validate each opt-in recurrent-state "
        "adapter under a common closure gate; the nonlinear multimode experiment "
        "remains the learning stress task."
    ),
    plot_description=(
        "Native and repeated-call solver error, neural-correction gain, solver-VJP "
        "lift, and held-out trajectories against the analytic TGV solution."
    ),
    runs=[
        {
            "ic": {"name": "tgv", "seed": 0},
            "physics": {
                "N": 64,
                "nu": 0.05,
                "dt": 0.01,
                "steps": 1,
                # Four XLB substeps are the smallest tested budget that keeps
                # both one-interval and uninterrupted t=1 error below 1%.
                "lbm_N_base": 16,
            },
            "dataset": {
                "reference_kind": "analytic_tgv",
                "reference_factor": 1,
                "reference_substeps": 1,
                "train_seeds": [0, 1, 2, 3],
                "test_seeds": [100, 101],
                "train_frames": 24,
                "long_closure_tolerance": 0.01,
            },
            "training": {
                "max_updates": 50,
                "unroll": 4,
                "loss_mode": "solver_terminal",
                "solver_loss_weight": 0.1,
                "loss_normalization": "solver_baseline",
                "loss_scale_floor": 1e-6,
                # Calibrated on training loss only. A nonlinear-task-size Adam
                # step overwhelms this near-floor, per-native-step residual.
                "lr": 1e-9,
                "clip_norm": 5.0,
                "architecture": "periodic_residual_cnn",
                "hidden_channels": 32,
                "kernel_size": 5,
                "seed": 2026,
                "model_seeds": [0, 1, 2],
                "check_grad": True,
                # The zero-initialized residual needs a smaller perturbation
                # than the nonlinear stress task for its local VJP check.
                "fd_epsilon": 3e-4,
            },
            "evaluation": {
                "rollout_frames": 100,
                "seen_ic_trajectories": 2,
                "stable_error_threshold": 1.0,
                "first_interval_error_tolerance": 0.01,
                "native_long_error_tolerance": 0.01,
            },
        }
    ],
    plot=plot_solver_in_loop_tgv,
)
problem.add_experiment(
    "optimization/solver_in_loop_self_reference",
    solver_in_loop,
    description=(
        "Rank solvers for solver-in-the-loop use. Each admitted solver's corrector "
        "is trained against that solver's own spatially and temporally refined "
        "trajectory, so every solver faces the same task -- remove your own "
        "discretization error using your own gradients -- and the ranked quantity "
        "is the fraction of its own coarse-to-fine gap the corrector closes. This "
        "mirrors the fairness of 3D initial-condition recovery, where each solver "
        "inverts its own forward map, and avoids the shared-target comparison's "
        "confound with raw forward accuracy. A direct semigroup audit gates "
        "training so the comparison measures credit assignment rather than "
        "state-reset artifacts."
    ),
    plot_description=(
        "Refinement-gap closure per solver (the ranked quantity), recurrence "
        "admission, paired solver-VJP lift, held-out trajectories, and training "
        "cost. Raw errors are not compared across solver-specific references; the "
        "normalized closure is."
    ),
    runs=[
        {
            "ic": {"name": "multimode", "seed": 0},
            "physics": {
                "N": 32,
                "nu": 0.001,
                "dt": 0.02,
                "steps": 4,
            },
            "dataset": {
                "reference_kind": "solver_self_refined",
                "reference_factor": 2,
                "reference_temporal_factor": 2,
                "train_seeds": list(range(16)),
                "test_seeds": list(range(100, 108)),
                "train_frames": 24,
                "k0": 2.0,
                "sigma_k": 0.5,
                "amplitude": 0.5,
                "prefix_audit_seeds": [0, 1, 100, 101],
                "prefix_audit_frames": [1, 8, 24, 36],
                "closure_relative_tolerance": 0.01,
                "closure_to_signal_tolerance": 0.1,
                "minimum_refinement_signal": 1e-4,
            },
            "training": {
                # A ranking at a non-converged budget ranks whoever trains
                # fastest. A 200 -> 1000 -> 4000 update ladder on the shared
                # -target task showed correction gain still climbing well past
                # 1000 updates for every solver, so the ranked protocol trains
                # to 3000 -- the largest matched budget that fits the 4h GPU
                # scheduling slot for the slowest solver.
                "max_updates": 3000,
                "unroll": 8,
                # The plain mean over corrected states beat the solver-terminal
                # objective at equal budget in a paired probe (JAX-CFD 1.059x
                # versus 0.988x correction gain at 4000 updates).
                "loss_mode": "mean",
                "solver_loss_weight": 0.0,
                "loss_normalization": "solver_baseline",
                "loss_scale_floor": 1e-6,
                "lr": 1e-4,
                "clip_norm": 5.0,
                "architecture": "periodic_residual_cnn",
                "hidden_channels": 32,
                "kernel_size": 5,
                "seed": 2026,
                "model_seeds": [0, 1, 2],
                "check_grad": True,
                "fd_epsilon": 1e-2,
            },
            "evaluation": {
                "rollout_frames": 36,
                "seen_ic_trajectories": 8,
                "stable_error_threshold": 1.0,
            },
        }
    ],
    plot=plot_solver_in_loop_self_reference,
)
# Bonus plot (not paired with an experiment).
problem.add_extra_plot(
    "_extra/gradient/jacobian_svd_comparison",
    plot_jacobian_svd_comparison,
)

# All per-solver exclusions live in :mod:`.exclusions`; one call attaches the
# whole table to the canonical :class:`Problem` instance.
_register_exclusions(problem)

__all__ = ["problem"]
