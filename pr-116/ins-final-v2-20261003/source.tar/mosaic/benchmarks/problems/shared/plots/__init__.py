# Copyright 2026 Pasteur Labs. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

from mosaic.benchmarks.problems.shared.plots.style import (
    apply_style,
    field_grid,
    grad_magnitude_2d,
    imshow_with_cbar,
    save_fig,
    solver_line_props,
    solver_plot_props,
    solver_styles,
    vorticity_2d,
)

__all__ = [
    "apply_style",
    "field_grid",
    "grad_magnitude_2d",
    "imshow_with_cbar",
    "save_fig",
    "solver_line_props",
    "solver_plot_props",
    "solver_styles",
    "vorticity_2d",
]
