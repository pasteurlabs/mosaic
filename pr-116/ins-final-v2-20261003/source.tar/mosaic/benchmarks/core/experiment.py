# Copyright 2026 Pasteur Labs. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

"""Generic harness scaffold for per-solver experiments with optional sweeps.

The core of every benchmark experiment is the same skeleton: walk the runs
payload, build the IC, iterate the selected solvers, for each solver iterate
the sweep, save snapshots and ``result.json``. This module owns that
skeleton so the per-experiment code shrinks to a tiny *kernel*.

A kernel is just a function:

    kernel(t, ctx) -> dict

where ``t`` is the tesseract handle and ``ctx`` is a :class:`KernelContext`
carrying the IC, physics, and per-call configuration. The return dict has
some or all of:

  * ``"metrics"`` — recorded under ``by_solver[name]`` (or
    ``by_solver[name][sweep_value]`` when sweeping).
  * ``"snapshot"`` — one array to save under the first
    ``snapshot_prefixes`` entry. Use this for single-array kernels.
  * ``"snapshots"`` — a ``{prefix: array}`` dict when the kernel emits
    multiple per-solver arrays (e.g. Jacobian + gradient).
  * ``"shared"`` — a ``{key: array}`` dict for arrays that belong at the
    NPZ top level (shared across solvers, e.g. the IC or the singular
    spectrum).

Kernels are decorated with :func:`kernel` so :meth:`Problem.add_experiment`
can hand them directly to the registry without an intermediate wrapper:

    @kernel(sweep_mode="default", horizons_shared=True)
    def param_sweep(t, ctx): ...

    problem.add_experiment("gradient/horizon_sweep", param_sweep, ...)

For experiments that need a post-pass across all solvers (Jacobian SVD,
cross-cosine, landscape pass), pass ``aggregate_fn=`` to the decorator —
it receives the populated state plus framework handles (cfg, tags,
gpu_ids, out_dir) and is responsible for both the final result dict and
any NPZ writing.
"""

from __future__ import annotations

import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

import jax
import jax.numpy as jnp
import numpy as np

from mosaic.benchmarks.core.config import Problem
from mosaic.benchmarks.core.console import console
from mosaic.benchmarks.core.hardware import ResourceSampler
from mosaic.benchmarks.core.harness import classify_failure
from mosaic.benchmarks.core.io import (
    experiment_dir,
    results_dir,
    save_field_snapshots_npz,
    save_harness_result,
)
from mosaic.benchmarks.core.memory import MemoryPoller, container_id_from_tesseract
from mosaic.benchmarks.core.partial import filter_resumable_solvers, write_partial
from mosaic.benchmarks.core.runner import current_worker_context, per_solver_loop
from mosaic.benchmarks.core.utils import (
    active_differentiable_solvers,
    iter_runs,
)


def random_direction(shape: tuple, key: jax.Array) -> jax.Array:
    """Unit-norm random direction in ``shape``-sized parameter space."""
    v = jax.random.normal(key, shape, dtype=jnp.float32)
    return v / (jnp.linalg.norm(v) + 1e-30)


# ── Unified result format ────────────────────────────────────────────────────

SCHEMA_VERSION = 1

# Max length of a stored failure/error string. Generous enough to keep a full
# Tesseract traceback (which the status report renders inside a collapsible
# <details> block) rather than clipping it after the first few stack frames.
MAX_ERROR_LEN = 4000


def _truncate_error(msg: str, limit: int = MAX_ERROR_LEN) -> str:
    """Clip a long error/traceback to *limit* chars, keeping both ends.

    A forwarded Tesseract "Error 500" message is the *remote* traceback: the
    actual exception (e.g. ``IndexError: ...``) sits at the very bottom, below
    a tall stack of FastAPI/starlette middleware frames. A plain ``msg[:limit]``
    keeps that boilerplate head and drops the real cause — exactly backwards.
    Keep a generous head plus the tail (where the cause lives) so the status
    report shows what actually went wrong.
    """
    if len(msg) <= limit:
        return msg
    marker = "\n... [traceback truncated] ...\n"
    budget = limit - len(marker)
    # Bias toward the tail: the head only needs enough to show the error type
    # and entry point; the cause is always at the end.
    head = budget // 3
    tail = budget - head
    return f"{msg[:head]}{marker}{msg[-tail:]}"


def _emit_sweep_failure(
    console_: Any,
    color: str,
    name: str,
    sweep_key: str | None,
    val: Any,
    metrics: dict,
) -> None:
    """Surface a per-sweep-point solver failure in the console and CI log.

    A *resource ceiling* (OOM / timeout) is an expected, platform-dependent
    scaling limit — printed dimly and NOT annotated (it would be noise on the
    Checks tab of every run). A real crash (compile error, NaN, container
    death) is a bug: printed red and, under GitHub Actions, emitted as a
    ``::warning`` so it shows on the Checks tab without anyone downloading
    result artifacts.
    """
    from mosaic.benchmarks.core.console import github_annotation

    failure_type = metrics.get("failure_type") or "error"
    exc_msg = metrics.get("exc_msg") or metrics.get("error") or ""
    short = str(exc_msg).strip().splitlines()[0][:120] if exc_msg else ""
    label = f"{sweep_key}={val}" if sweep_key is not None else "value"
    is_resource_ceiling = failure_type in ("OOM", "timeout")
    if is_resource_ceiling:
        console_.print(
            f"  [dim]{name} {label} resource ceiling ({failure_type}) — "
            f"expected at large sizes[/]"
        )
        return
    console_.print(
        f"  [{color}]{name}[/] [red]FAIL[/] {label} ({failure_type})"
        + (f": {short}" if short else "")
    )
    github_annotation(
        "warning",
        f"{name} failed at {label} ({failure_type})" + (f": {short}" if short else ""),
        title=f"Benchmark solver failure: {name}",
    )


def _flatten_by_solver(by_solver: dict, sweep_key: str | None) -> list[dict]:
    """Convert the kernel's ``by_solver`` accumulator into a flat results list.

    Each entry is ``{solver, sweep_value, metrics}``.
    """
    entries: list[dict] = []
    for solver, data in by_solver.items():
        if sweep_key is None:
            entries.append(
                {"solver": solver, "sweep_value": None, "metrics": data or {}}
            )
        else:
            if isinstance(data, dict):
                for val, metrics in data.items():
                    entries.append(
                        {
                            "solver": solver,
                            "sweep_value": str(val),
                            "metrics": metrics or {},
                        }
                    )
            else:
                entries.append(
                    {"solver": solver, "sweep_value": None, "metrics": data or {}}
                )
    return entries


def _build_result_envelope(
    *,
    cfg: Problem,
    suite: str,
    exp_key: str,
    run: dict,
    sweep_key: str | None,
    sweep_values: list | None,
    results: list[dict],
    extras: dict | None = None,
) -> dict:
    """Build the canonical result envelope (schema_version=1)."""
    envelope: dict = {
        "schema_version": SCHEMA_VERSION,
        "experiment": {
            "domain": cfg.name,
            "suite": suite,
            "name": exp_key,
        },
        "params": run,
        "sweep": (
            {"key": sweep_key, "values": [str(v) for v in sweep_values]}
            if sweep_key and sweep_values
            else None
        ),
        "results": results,
    }
    if extras:
        envelope["extras"] = extras
    return envelope


def merge_results(a: dict, b: dict) -> dict:
    """Merge two schema_version=1 result files. *b* wins on conflict."""
    seen: dict[tuple, dict] = {}
    for entry in a.get("results", []) + b.get("results", []):
        seen[(entry["solver"], entry.get("sweep_value"))] = entry
    merged = {**a, **b, "results": list(seen.values())}
    # Merge provenance sub-dicts
    for key in ("tesseract_hashes", "wall_time_s"):
        a_val = a.get("provenance", {}).get(key, {})
        b_val = b.get("provenance", {}).get(key, {})
        if a_val or b_val:
            merged.setdefault("provenance", {})[key] = {**a_val, **b_val}
    # Merge extras
    a_extras = a.get("extras", {})
    b_extras = b.get("extras", {})
    if a_extras or b_extras:
        merged["extras"] = {**a_extras, **b_extras}
    return merged


@dataclass
class KernelContext:
    """Argument bundle handed to each kernel invocation.

    Kernels ignore any field that isn't relevant to their science.
    """

    name: str  # solver name (e.g., "jax_cfd")
    cfg: Problem  # the full Problem — for solver metadata (color, etc.)
    ic: jax.Array  # initial condition (regenerated per value if ic_sweep=True)
    phys: dict[str, Any]  # physics dict, including domain_extent + current sweep value
    sweep_key: str | None  # None for sweep_mode="none"
    sweep_value: Any | None  # None for sweep_mode="none"
    ic_key: str
    output_key: str
    make_inputs: Callable
    domain_extent: float
    run: dict = field(
        default_factory=dict
    )  # full per-run payload for kernel-specific config
    seed: int = 0


Kernel = Callable[[Any, KernelContext], dict]
AggregateFn = Callable[..., dict]


_KERNEL_CONFIG_ATTR = "_mosaic_kernel_config"


def kernel(
    *,
    sweep_mode: str = "none",
    warmup: bool = False,
    ic_sweep: bool = False,
    horizons_shared: bool = False,
    aggregate_fn: AggregateFn | None = None,
    catch: bool = True,
    catch_label: str = "kernel failed",
    selector_fn: Callable[..., list[str]] = active_differentiable_solvers,
    snapshot_filename: str = "gradient_fields.npz",
    snapshot_prefixes: tuple[str, ...] = ("grad",),
) -> Callable:
    """Decorator: tag a ``(t, ctx) -> dict`` function as an experiment kernel.

    Attaches a ``_mosaic_kernel_config`` attribute that
    :meth:`Problem.add_experiment` reads to route registration through
    :func:`run_experiment`.
    """

    def decorate(fn: Callable) -> Callable:
        setattr(
            fn,
            _KERNEL_CONFIG_ATTR,
            {
                "sweep_mode": sweep_mode,
                "warmup": warmup,
                "ic_sweep": ic_sweep,
                "horizons_shared": horizons_shared,
                "aggregate_fn": aggregate_fn,
                "catch": catch,
                "catch_label": catch_label,
                "selector_fn": selector_fn,
                "snapshot_filename": snapshot_filename,
                "snapshot_prefixes": snapshot_prefixes,
            },
        )
        return fn

    return decorate


def is_kernel(fn: object) -> bool:
    """True iff ``fn`` was decorated with :func:`kernel`."""
    return hasattr(fn, _KERNEL_CONFIG_ATTR)


def get_kernel_config(fn: object) -> dict:
    """Return the framework config attached by :func:`kernel` (or empty)."""
    return getattr(fn, _KERNEL_CONFIG_ATTR, {})


def run_experiment(
    cfg: Problem,
    tags: dict[str, str],
    kernel_fn: Kernel,
    *,
    suite: str,
    exp_key: str,
    runs: Any,
    make_ic: Any,
    make_inputs: Any,
    output_key: str,
    ic_key: str,
    domain_extent: float,
    sweep_mode: str = "none",
    warmup: bool = False,
    ic_sweep: bool = False,
    selector_fn: Callable[..., list[str]] = active_differentiable_solvers,
    catch: bool = True,
    catch_label: str = "kernel failed",
    aggregate_fn: AggregateFn | None = None,
    snapshot_filename: str = "gradient_fields.npz",
    snapshot_prefixes: tuple[str, ...] = ("grad",),
    horizons_shared: bool = False,
    **overrides: Any,
) -> dict:
    """Generic per-solver experiment driver.

    Called from the closure :meth:`Problem.add_experiment` builds; not
    typically invoked directly. ``save_harness_result`` is called with
    ``harness_fn=kernel_fn`` so editing the kernel invalidates cached results.
    """
    if sweep_mode not in ("none", "default", "limits"):
        raise ValueError(
            f"sweep_mode must be 'none' | 'default' | 'limits', got {sweep_mode!r}"
        )
    if not runs:
        raise NotImplementedError(
            f"{exp_key!r}: requires runs= payload (not configured for {cfg.name!r})"
        )

    all_results: dict = {}

    for run in iter_runs(runs, overrides):
        ic_cfg = run.get("ic", {})
        ic_name = ic_cfg.get("name", next(iter(make_ic)))
        seed = ic_cfg.get("seed", 0)
        base_phys = run.get("physics", {})
        run_ic_key = run.get("ic_key", ic_key)
        run_output_key = run.get("output_key", output_key)
        gpu_ids = overrides.get("gpu_ids")

        sweep_key: str | None = None
        sweep_values: list = []
        ic_sweep_flag = False
        if sweep_mode != "none":
            sweep_cfg = run.get("sweep", {})
            sweep_key = sweep_cfg.get("key")
            sweep_values = sweep_cfg.get("values", [])
            # Kernel decorator's ``ic_sweep=True`` is the default — the run
            # dict's ``sweep.ic_sweep`` can still flip it on per registration
            # (and stays the only place to flip it on for kernels whose
            # default is False).
            ic_sweep_flag = sweep_cfg.get("ic_sweep", ic_sweep)
            if not sweep_key or not sweep_values:
                raise NotImplementedError(
                    f"{exp_key!r}: requires sweep.key and sweep.values in runs payload"
                )

        if ic_sweep_flag:
            ic_per_val: dict = {
                v: make_ic[ic_name](
                    L=domain_extent, seed=seed, **{**base_phys, sweep_key: v}
                )
                for v in sweep_values
            }
            base_ic = ic_per_val[sweep_values[0]]
        else:
            ic_per_val = None
            base_ic = make_ic[ic_name](L=domain_extent, seed=seed, **base_phys)

        if sweep_mode == "limits" and gpu_ids is None:
            console.print(
                f"  [yellow]WARN[/] {exp_key}: gpu_ids not set — solvers share all "
                "GPUs. Pass --gpu-ids 0 1 2 3 for isolated per-GPU OOM measurements."
            )

        # Compute out_dir early so filter_resumable_solvers and
        # write_partial can use it before/during the solver loop.
        exp_subdir = exp_key
        out_dir = experiment_dir(
            results_dir(),
            cfg.name,
            suite,
            exp_subdir,
            suffix="_debug" if overrides.get("debug") else "",
        )

        selected = selector_fn(cfg, suite, exp_key)
        # ``mosaic run --only failed,stale,…`` installs a per-cell filter
        # before the experiment loop. When set, prune the active solver
        # list to cells matching the requested state(s); when unset this
        # is a no-op pass-through.
        from .cell_filter import filter_solvers

        selected = filter_solvers(f"{suite}/{exp_key}", selected)
        # On --continue, drop solvers already recorded as complete in a
        # prior partial checkpoint so they are not re-run.
        selected = filter_resumable_solvers(selected, out_dir, overrides)
        by_solver: dict = {}
        snapshots: dict[str, dict[str, np.ndarray]] = {}
        shared_extras: dict[str, np.ndarray] = {}
        # Solvers whose Tesseract container failed to start (or whose work
        # raised). Forwarded into the result so the status classifier marks
        # them FAILED instead of NOT_RUN — otherwise a broken container is
        # silently indistinguishable from a solver that wasn't selected.
        solver_failures: dict[str, str] = {}

        def _on_solver_error(
            name: str,
            exc: Exception,
            _sf: dict[str, str] = solver_failures,
        ) -> None:
            _sf[name] = _truncate_error(f"{type(exc).__name__}: {exc}")

        def _ctx(
            name: str,
            val: Any,
            _ic_per_val: dict | None = ic_per_val,
            _base_ic: Any = base_ic,
            _base_phys: dict = base_phys,
            _sweep_key: str | None = sweep_key,
            _run_ic_key: str = run_ic_key,
            _run_output_key: str = run_output_key,
            _run: dict = run,
            _seed: int = seed,
        ) -> KernelContext:
            _ic = _ic_per_val[val] if _ic_per_val is not None else _base_ic
            phys = {**_base_phys, "domain_extent": domain_extent}
            if _sweep_key is not None:
                phys[_sweep_key] = val
            return KernelContext(
                name=name,
                cfg=cfg,
                ic=_ic,
                phys=phys,
                sweep_key=_sweep_key,
                sweep_value=val,
                ic_key=_run_ic_key,
                output_key=_run_output_key,
                make_inputs=make_inputs,
                domain_extent=domain_extent,
                run=_run,
                seed=_seed,
            )

        def _absorb(
            out: dict,
            solver_snaps: dict[str, np.ndarray],
            idx_suffix: str,
            _shared_extras: dict[str, np.ndarray] = shared_extras,
        ) -> None:
            """Fold one kernel return into ``solver_snaps`` and ``shared_extras``.

            ``idx_suffix`` is the sweep-iteration suffix ("" for sweep_mode="none",
            ``str(idx)`` otherwise). Multi-prefix snapshots are stored using
            the ``"prefix:" + suffix`` convention that
            :func:`save_field_snapshots_npz` parses.
            """
            single = out.get("snapshot")
            if single is not None:
                solver_snaps[idx_suffix] = np.asarray(single)
            multi = out.get("snapshots") or {}
            for prefix, arr in multi.items():
                solver_snaps[f"{prefix}:{idx_suffix}"] = np.asarray(arr)
            for k, v in (out.get("shared") or {}).items():
                _shared_extras.setdefault(k, np.asarray(v))

        def _call_with_sampler(name: str, t: Any, val: Any) -> dict:
            """Run one kernel invocation with a cheap before/after VRAM+RAM sampler.

            The sampler's ``vram_peak_mib`` / ``ram_peak_mib`` get merged into
            the kernel's metrics via :func:`dict.setdefault`, so kernels that
            already compute their own resource stats (cost suite — true peak
            via ``run_timed_trials``) take precedence. Sampler overhead is a
            handful of NVML/psutil calls (~3–5 ms), so we pay it
            unconditionally; this gives every kernel result a baseline
            VRAM/RAM read without per-kernel boilerplate.
            """
            with ResourceSampler(gpu_id=current_worker_context().gpu_id) as rs:
                out = kernel_fn(t, _ctx(name, val))
            metrics = out.setdefault("metrics", {})
            for k, v in rs.summary.items():
                if v is not None:
                    metrics.setdefault(k, v)
            return out

        # Partial-result checkpointing: after each solver finishes its
        # work, snapshot ``by_solver`` to ``result_partial.json`` so a
        # crash between solvers doesn't lose completed work. On the next
        # ``mosaic run --continue``, filter_resumable_solvers (above)
        # reads this file and skips solvers already recorded as done.
        _partial_lock = threading.Lock()

        def _checkpoint_solver(
            name: str,
            _out_dir: Any = out_dir,
            _by_solver: dict = by_solver,
            _run: dict = run,
            _lock: threading.Lock = _partial_lock,
        ) -> None:
            write_partial(
                _out_dir,
                {
                    "by_solver": {n: {} for n in _by_solver if _by_solver[n]},
                    "params": _run,
                },
                _lock,
            )

        def _work(
            name: str,
            t: Any,
            _by_solver: dict = by_solver,
            _snapshots: dict[str, dict[str, np.ndarray]] = snapshots,
            _sweep_values: list = sweep_values,
            _sweep_key: str | None = sweep_key,
        ) -> None:
            if sweep_mode == "none":
                out = _call_with_sampler(name, t, None)
                _by_solver[name] = out.get("metrics", {})
                solver_snaps: dict[str, np.ndarray] = {}
                _absorb(out, solver_snaps, "")
                if solver_snaps:
                    _snapshots[name] = solver_snaps
                _checkpoint_solver(name)
                return

            if warmup and _sweep_values:
                color = cfg.solver(name).color
                try:
                    kernel_fn(t, _ctx(name, _sweep_values[0]))
                    console.print(f"  [{color}]{name}[/] warmup ok")
                except Exception as wex:
                    console.print(
                        f"  [{color}]{name}[/] warmup skipped ({type(wex).__name__})"
                    )

            solver_results: dict = {}
            solver_snaps: dict[str, np.ndarray] = {}

            if sweep_mode == "default":
                color = cfg.solver(name).color
                stopped_at: int | None = None
                for idx, val in enumerate(_sweep_values):
                    out = _call_with_sampler(name, t, val)
                    metrics = out.get("metrics", {})
                    solver_results[val] = metrics
                    _absorb(out, solver_snaps, str(idx))
                    # A kernel signals it wants the sweep abandoned via
                    # ``stop_reason`` ("wall_limit" | "error") — or, for legacy
                    # kernels, a bare ``stop_sweep`` boolean.
                    #
                    # We short-circuit the remaining values on any *monotone*
                    # stop — wall-limit, or a resource ceiling (OOM / timeout),
                    # or a legacy kernel that short-circuits because the failure
                    # is a function of the solver rather than the sweep value.
                    # Larger sizes would only fare worse, so trying them wastes
                    # time. A hard *error* (compile error, NaN) is NOT monotone
                    # — a larger sweep value may compile/run fine (e.g. a
                    # power-of-two grid size after a non-power-of-two crashed) —
                    # so we log it and CONTINUE rather than hiding the untried
                    # points behind an empty cell.
                    stop_reason = out.get("stop_reason")
                    if stop_reason is None and out.get("stop_sweep"):
                        stop_reason = "wall_limit"
                    if isinstance(metrics, dict) and metrics.get("status") == "failed":
                        _emit_sweep_failure(
                            console, color, name, _sweep_key, val, metrics
                        )
                    if stop_reason is not None and stop_reason != "error":
                        stopped_at = idx
                        break
                if stopped_at is not None:
                    # Distinct, visible "skipped" state — NOT ``None``/``{}``,
                    # which is indistinguishable from "never selected". The
                    # status classifier treats it as a benign "didn't run" and
                    # the cost plots draw it as a gap rather than a data point.
                    skip_reason = (
                        f"skipped after sweep stopped at "
                        f"{_sweep_key}={_sweep_values[stopped_at]}"
                    )
                    for remaining in _sweep_values[stopped_at + 1 :]:
                        solver_results[remaining] = {
                            "status": "skipped",
                            "reason": skip_reason,
                        }
                _by_solver[name] = solver_results
                if solver_snaps:
                    _snapshots[name] = solver_snaps
                _checkpoint_solver(name)
                return

            # sweep_mode == "limits"
            color = cfg.solver(name).color
            _gpu_id = current_worker_context().gpu_id
            _cid = container_id_from_tesseract(t)
            failed = False
            fail_reason = ""

            for idx, val in enumerate(_sweep_values):
                if failed:
                    solver_results[val] = {"status": "skipped", "reason": fail_reason}
                    continue
                t_step = time.perf_counter()
                with MemoryPoller(_gpu_id, _cid) as poller:
                    try:
                        out = kernel_fn(t, _ctx(name, val))
                        exc: Exception | None = None
                    except Exception as e:
                        out, exc = None, e
                mem = poller.summary
                step_wall = time.perf_counter() - t_step
                vram_str = (
                    f" vram={mem['vram_peak_mib']:.0f}MiB"
                    if mem.get("vram_peak_mib") is not None
                    else ""
                )
                if exc is None:
                    metrics = {
                        **(out.get("metrics") if out else {}),
                        "status": "ok",
                        "wall_time_s": step_wall,
                        **mem,
                    }
                    solver_results[val] = metrics
                    _absorb(out, solver_snaps, str(idx))
                    ram_str = (
                        f" ram={mem['ram_peak_mib']:.0f}MiB"
                        if mem.get("ram_peak_mib") is not None
                        else ""
                    )
                    gn = metrics.get("grad_norm")
                    gn_str = f" grad_norm={gn:.3g}" if isinstance(gn, float) else ""
                    console.print(
                        f"  [{color}]{name}[/] {_sweep_key}={val} ok"
                        f"{gn_str}{vram_str}{ram_str} ({step_wall:.1f}s)"
                    )
                else:
                    failure_type = classify_failure(type(exc).__name__, str(exc))
                    err_short = _truncate_error(str(exc))
                    solver_results[val] = {
                        "status": "failed",
                        "failure_type": failure_type,
                        "error": err_short,
                        "wall_time_s": step_wall,
                        **mem,
                    }
                    fail_reason = (
                        f"first failure at {_sweep_key}={val} ({failure_type})"
                    )
                    failed = True
                    console.print(
                        f"  [{color}]{name}[/] [red]FAIL[/] {_sweep_key}={val} "
                        f"({failure_type}){vram_str}: {err_short[:80]} ({step_wall:.1f}s)"
                    )

            _by_solver[name] = solver_results
            if solver_snaps:
                _snapshots[name] = solver_snaps
            _checkpoint_solver(name)

        wall_times = per_solver_loop(
            cfg,
            tags,
            selected,
            _work,
            gpu_ids=gpu_ids,
            # "limits" mode catches its own per-step failures inline; outer
            # catch would swallow programming errors silently.
            catch=catch and sweep_mode != "limits",
            catch_label=catch_label,
            on_error=_on_solver_error,
        )

        # Aggregate is responsible for both the final result dict and any
        # custom NPZ saving (Jacobian SVD writes singular-value arrays the
        # framework has no way to produce). Default path: framework saves a
        # standard NPZ + builds a vanilla result dict.
        if aggregate_fn is None:
            if snapshots:
                shared = {"ic": np.asarray(base_ic), **shared_extras}
                if horizons_shared and sweep_key and sweep_values:
                    shared["horizons"] = np.array(
                        [
                            float(v) * float(base_phys.get("dt", 1.0))
                            for v in sweep_values
                        ]
                        if sweep_key == "steps"
                        else [float(v) for v in sweep_values]
                    )
                save_field_snapshots_npz(
                    out_dir,
                    list(snapshots.keys()),
                    snapshots,
                    shared_arrays=shared,
                    filename=snapshot_filename,
                    prefixes=snapshot_prefixes,
                )
            result = _build_result_envelope(
                cfg=cfg,
                suite=suite,
                exp_key=exp_key,
                run=run,
                sweep_key=sweep_key,
                sweep_values=sweep_values if sweep_key else None,
                results=_flatten_by_solver(by_solver, sweep_key),
            )
        else:
            result = aggregate_fn(
                by_solver,
                run=run,
                cfg=cfg,
                tags=tags,
                suite=suite,
                exp_key=exp_key,
                out_dir=out_dir,
                selected=selected,
                gpu_ids=gpu_ids,
                snapshots=snapshots,
                shared_extras=shared_extras,
                ic=base_ic,
                sweep_values=sweep_values,
                sweep_key=sweep_key,
                snapshot_filename=snapshot_filename,
                snapshot_prefixes=snapshot_prefixes,
                horizons_shared=horizons_shared,
            )

        # Propagate solver-level failures (container start failed, work raised)
        # so the status classifier marks them FAILED rather than NOT_RUN.
        if solver_failures and isinstance(result, dict):
            existing = result.get("_solver_failures") or {}
            existing.update(solver_failures)
            result["_solver_failures"] = existing

        # Persist this experiment's sweep coordinates so aggregator plots
        # (and downstream readers) don't need to re-parse the experiment
        # name to discover its position in parameter space.
        if isinstance(result, dict):
            _exp = cfg.experiments.get(f"{suite}/{exp_key}")
            if _exp is not None and _exp.coords:
                result.setdefault("coords", dict(_exp.coords))

        save_harness_result(
            result,
            cfg=cfg,
            suite=suite,
            exp_subdir=exp_subdir,
            harness_fn=kernel_fn,
            wall_time_s=wall_times,
            debug=bool(overrides.get("debug")),
        )
        all_results = result

    return all_results
