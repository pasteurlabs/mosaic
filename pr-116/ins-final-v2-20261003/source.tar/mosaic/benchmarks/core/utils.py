# Copyright 2026 Pasteur Labs. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

"""Array math, run iteration, and solver-filtering utilities.

Filesystem I/O (JSON/CSV/NPZ helpers, ``save_experiment``,
``save_field_snapshots_npz``, content hashing, ``results_dir``,
``experiment_dir``) lives in :mod:`mosaic.benchmarks.core.io`. This module
contains the non-I/O utilities that don't fit anywhere more specific:

  * Array math: :func:`trimmed_mean`, :func:`l2_error_rel`, :func:`is_valid`.
  * Run iteration: :func:`iter_runs`, :func:`_debug_run`.
  * Solver filtering: :func:`exclusion_lookup`, :func:`active_solvers`,
    :func:`active_differentiable_solvers`.
"""

from __future__ import annotations

from collections.abc import Iterator

import jax
import jax.numpy as jnp

from .config import Problem

# ── Array statistics ──────────────────────────────────────────────────────────


def trimmed_mean(arrays: list, q_lo: float = 0.05, q_hi: float = 0.95) -> jax.Array:
    """Per-element trimmed mean across a list of same-shape arrays.

    With n <= 2 arrays, quantile linear interpolation places lo strictly above
    the minimum and hi strictly below the maximum, so both values fail the mask
    and the result collapses to zero.  For small n we fall back to the plain mean.

    When the quantile bracket eliminates all values at a position (e.g. 4 nearly
    identical scalars where float interpolation pushes lo above every value),
    the plain mean is used at those positions as a fallback.

    Non-finite entries are left out per element. A solver that returns NaN at
    one point would otherwise carry it into the reference, and every other
    solver's error against that reference becomes NaN with it. A position where
    no solver is finite stays NaN, which is the honest answer there.
    """
    stacked = jnp.stack(arrays, axis=0)  # (n, ...)
    finite = jnp.isfinite(stacked)
    n_finite = finite.sum(axis=0)

    def _mean_where(keep: jax.Array, n: jax.Array) -> jax.Array:
        # jnp.where rather than a product: inf * False is nan, so multiplying
        # by the mask would reintroduce the value being excluded.
        total = jnp.where(keep, stacked, 0.0).sum(axis=0)
        return jnp.where(n > 0, total / jnp.maximum(n, 1), jnp.nan)

    finite_mean = _mean_where(finite, n_finite)
    if len(arrays) <= 2:
        return finite_mean

    masked = jnp.where(finite, stacked, jnp.nan)
    lo = jnp.nanquantile(masked, q_lo, axis=0)
    hi = jnp.nanquantile(masked, q_hi, axis=0)
    mask = finite & (stacked >= lo) & (stacked <= hi)
    count = mask.sum(axis=0)
    return jnp.where(count > 0, _mean_where(mask, count), finite_mean)


def l2_error_rel(pred: object, ref: object) -> float:
    """Relative L2 error ||pred-ref|| / ||ref||."""
    return float(
        jnp.sqrt(jnp.mean((pred - ref) ** 2)) / (jnp.sqrt(jnp.mean(ref**2)) + 1e-30)
    )


def is_valid(arr: object) -> bool:
    """Return True iff *arr* is not None and contains only finite values."""
    return arr is not None and bool(jnp.all(jnp.isfinite(arr)))


# ── Run iteration ─────────────────────────────────────────────────────────────


def iter_runs(runs: list[dict] | None, cli_overrides: dict) -> Iterator[dict]:
    """Yield run configs from a runs list, applying debug and IC filters.

    Each run dict has named sub-groups: ic, physics, sweep, fd, optim, jacobian,
    fine, cost.  Yields a deep-copied, debug-adjusted run per matching entry.

    cli_overrides keys consumed here (read-only, never mutated):
        ic_names   — list[str]: filter to runs whose ic.name is in the list
        debug      — bool: cap physics sizes and truncate sweep lists
    """
    import copy

    if runs is None:
        return

    ic_filter = cli_overrides.get("ic_names")
    debug = cli_overrides.get("debug", False)

    for run in runs:
        ic_name = run.get("ic", {}).get("name", "")
        if ic_filter and ic_name not in ic_filter:
            continue
        run = copy.deepcopy(run)
        if debug:
            _debug_run(run)
        yield run


def _debug_run(run: dict) -> None:
    """Reduce run complexity for debug mode (mutates run in place)."""
    phys = run.setdefault("physics", {})
    for key, cap in [
        ("N", 16),
        ("nx", 8),
        ("steps", 5),
        ("chunk_steps", 5),
        ("n_chunks", 2),
    ]:
        if key in phys:
            phys[key] = min(phys[key], cap)
    # Keep ny consistent with capped nx (canonical 2:1 aspect ratio)
    if "nx" in phys and "ny" in phys:
        phys["ny"] = min(phys["ny"], max(1, phys["nx"] // 2))
    fd = run.setdefault("fd", {})
    for key, cap in [("n_dirs", 2), ("n_alphas", 5)]:
        if key in fd:
            fd[key] = min(fd[key], cap)
    if "eps_values" in fd:
        fd["eps_values"] = list(fd["eps_values"])[:2]
    sweep = run.get("sweep", {})
    if "values" in sweep:
        vals = list(sweep["values"])
        # For resolution (N) sweeps, skip pathologically coarse values where
        # all FEM solvers return identical results (trivial DOF count) or the
        # reference field is near-zero giving astronomical relative errors.
        if sweep.get("key") == "N":
            sane = [v for v in vals if v >= 4]
            if sane:
                vals = sane
        sweep["values"] = vals[:2]
    optim = run.get("optim", {})
    for key, cap in [("max_iters", 50), ("patience", 10)]:
        if key in optim:
            optim[key] = min(optim[key], cap)
    training = run.get("training", {})
    for key, cap in [
        ("max_updates", 2),
        ("unroll", 2),
        ("hidden_channels", 8),
        ("kernel_size", 3),
    ]:
        if key in training:
            training[key] = min(training[key], cap)
    if training:
        training["check_grad"] = False
    if "model_seeds" in training:
        training["model_seeds"] = list(training["model_seeds"])[:1]
    dataset = run.get("dataset", {})
    for key in ("train_seeds", "test_seeds"):
        if key in dataset:
            dataset[key] = list(dataset[key])[:1]
    if "prefix_audit_seeds" in dataset:
        retained_seeds = set(dataset.get("train_seeds", [])) | set(
            dataset.get("test_seeds", [])
        )
        dataset["prefix_audit_seeds"] = [
            seed for seed in dataset["prefix_audit_seeds"] if seed in retained_seeds
        ]
    if "train_frames" in dataset:
        dataset["train_frames"] = min(dataset["train_frames"], 3)
    evaluation = run.get("evaluation", {})
    if "rollout_frames" in evaluation:
        evaluation["rollout_frames"] = min(evaluation["rollout_frames"], 3)
    if "prefix_audit_frames" in dataset:
        max_frame = max(
            int(dataset.get("train_frames", 0)),
            int(evaluation.get("rollout_frames", 0)),
            int(training.get("unroll", 0)),
        )
        dataset["prefix_audit_frames"] = [
            frame for frame in dataset["prefix_audit_frames"] if frame <= max_frame
        ]
    cost = run.get("cost", {})
    for key in ("N_values", "steps_values"):
        if key in cost:
            cost[key] = list(cost[key])[:2]
    if "n_trials" in cost:
        cost["n_trials"] = 1


def exclusion_lookup(
    exclusions: dict,
    suite: str,
    experiment: str | None = None,
    sub: str | None = None,
) -> tuple[str, object] | None:
    """Look up the most-specific exclusion entry for (suite, experiment[, sub]).

    Returns ``(matched_key, value)`` or ``None``. A key matches if it equals
    the full ``"<suite>/<experiment>[/<sub>]"`` path OR is a prefix-component
    of it (``"<suite>/<experiment>"``, ``"<suite>"``). The longest matching
    key wins, so a config can target one experiment (``forward/cylinder``) or
    a whole suite (``gradient``) without needing a fallback chain.

    Used by both :func:`active_solvers` (runtime gating) and
    :mod:`core.status` (display) so the two paths can't drift on precedence.
    """
    if not exclusions:
        return None
    # Full path: "<suite>", "<suite>/<exp>", "<suite>/<exp>/<sub>".
    parts: list[str] = [suite]
    if experiment:
        parts.extend(experiment.split("/"))
    if sub:
        parts.extend(sub.split("/"))
    # Try longest prefix first.
    for n in range(len(parts), 0, -1):
        key = "/".join(parts[:n])
        if key in exclusions:
            return key, exclusions[key]
    return None


def active_solvers(
    cfg: Problem, suite: str, experiment: str | None = None
) -> list[str]:
    """Solver names not excluded for *suite* (and optionally *experiment*).

    Reads ``cfg.exclusions[name]`` via :func:`exclusion_lookup`, which tries
    the most-specific key first (``"suite/experiment"``) and falls back to
    the bare experiment key and finally to ``suite``. ``mosaic status`` uses
    the same lookup so the runtime filter and the display can never disagree
    on which cells are gated.

    ``Exclusion(category="anomaly_explained", ...)`` is treated as
    *not excluded* — the solver runs and produces output that's flagged in
    the status display but not skipped at runtime.

    Prints a one-line warning per excluded solver, naming the matched key so
    the exclusion source is visible in runner output.
    """
    from .console import console

    result = []
    for spec in cfg.solvers:
        name = spec.name
        match = exclusion_lookup(cfg.exclusions.get(spec.key, {}), suite, experiment)
        if match is None:
            result.append(name)
            continue
        matched_key, value = match
        if getattr(value, "category", None) == "anomaly_explained":
            # Explained-anomaly is a display annotation, not a runtime skip.
            result.append(name)
            continue
        reason = getattr(value, "reason", value)
        console.print(
            f"  [yellow]SKIP {name}[/] excluded from {matched_key!r}: {reason}"
        )
    return result


def active_differentiable_solvers(
    cfg: Problem, suite: str = "gradient", experiment: str | None = None
) -> list[str]:
    """Differentiable solvers not excluded for *suite* (and optionally *experiment*)."""
    from mosaic.benchmarks.core.config import has_vjp

    return [
        name
        for name in active_solvers(cfg, suite, experiment)
        if has_vjp(cfg.solver(name))
    ]
