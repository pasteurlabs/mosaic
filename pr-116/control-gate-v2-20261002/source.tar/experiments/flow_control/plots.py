"""Full-field plots for development gates; render only inside a Slurm job."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def plot_gate(arrays: dict, metrics: dict, destination: Path) -> None:
    """Show physical outcomes and optimization history without implying learning."""
    destination.mkdir(parents=True, exist_ok=True)
    for index, row in enumerate(metrics["tasks"]):
        goal = arrays["fine_goal"][index, :, :, 0, :]
        zero = arrays["fine_zero_rollouts"][index, -1, :, :, 0, :]
        controlled = arrays["fine_shooting_rollouts"][index, -1, :, :, 0, :]
        fields = [goal, zero, controlled]
        dx = 2 * np.pi / goal.shape[0]
        curls = [
            (
                np.roll(v[..., 1], -1, axis=0)
                - np.roll(v[..., 1], 1, axis=0)
                - np.roll(v[..., 0], -1, axis=1)
                + np.roll(v[..., 0], 1, axis=1)
            )
            / (2 * dx)
            for v in fields
        ]
        vmax = max(float(np.max(np.abs(c))) for c in curls) or 1
        errors = [np.linalg.norm(v - goal, axis=-1) for v in (zero, controlled)]
        emax = max(float(e.max()) for e in errors) or 1
        fig, axes = plt.subplots(2, 3, figsize=(13, 8), layout="constrained")
        for ax, curl, title in zip(
            axes[0], curls, ["Target", "No control", "Optimized control"], strict=True
        ):
            im = ax.imshow(
                curl.T,
                origin="lower",
                extent=(0, 2 * np.pi, 0, 2 * np.pi),
                cmap="RdBu_r",
                vmin=-vmax,
                vmax=vmax,
            )
            ax.set(title=title, xlabel="x", ylabel="y")
        fig.colorbar(im, ax=axes[0].tolist(), label="Terminal vorticity", shrink=0.8)
        for ax, error, title in zip(
            axes[1, :2],
            errors,
            ["No control: velocity error", "Optimized: velocity error"],
            strict=True,
        ):
            im = ax.imshow(
                error.T,
                origin="lower",
                extent=(0, 2 * np.pi, 0, 2 * np.pi),
                cmap="magma",
                vmin=0,
                vmax=emax,
            )
            ax.set(title=title, xlabel="x", ylabel="y")
        fig.colorbar(
            im, ax=axes[1, :2].tolist(), label="Velocity error magnitude", shrink=0.8
        )
        trace = row["shooting"]["trace"]
        axes[1, 2].plot(np.arange(len(trace)), trace, color="#0072B2")
        axes[1, 2].set(
            title="Direct optimization at 64²",
            xlabel="Gradient update",
            ylabel="Terminal error + control effort",
        )
        axes[1, 2].grid(alpha=0.2)
        status = "passed" if row["passed"] else "FAILED"
        fig.suptitle(
            f"Control gate · task {row['seed']} · 192² evaluation · {status}\n"
            "Individual optimized controls; no neural controller trained yet",
            fontsize=13,
        )
        fig.savefig(destination / f"task-{row['seed']}.png", dpi=160)
        plt.close(fig)
