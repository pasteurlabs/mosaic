"""Run one frozen neural-control gate on an allocated GPU."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from types import SimpleNamespace

import jax
import numpy as np
from tesseract_core import Tesseract

from experiments.flow_control.control import ControlConfig, run_gate
from experiments.flow_control.plots import plot_gate
from mosaic.benchmarks.problems import get_config


def main() -> None:
    """Execute a gate and retain every diagnostic and full field."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--url", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    payload = json.loads(args.config.read_text())
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "protocol.json").write_text(json.dumps(payload, indent=2))
    if jax.default_backend() != "gpu":
        raise RuntimeError("Control experiments require the allocated GPU")
    control = ControlConfig(**payload.get("control", {}))
    cfg = get_config("ns-grid")
    spec = next(s for s in cfg.solvers if s.key == "phiflow")
    ctx = SimpleNamespace(
        name=spec.name,
        make_inputs=cfg.make_inputs,
        phys={"nu": control.nu, "dt": control.dt, "steps": control.steps_per_slot},
        domain_extent=control.domain_extent,
        run={"execution": {"jit_solver_rpc": False}},
        output_key="result",
    )
    with Tesseract.from_url(args.url, timeout=(30, 1200)) as solver:
        print(f"solver_health={solver.health()}", flush=True)
        result = run_gate(
            solver,
            ctx,
            control,
            seeds=payload["task_seeds"],
        )
    np.savez_compressed(args.out / "fields.npz", **result["arrays"])
    (args.out / "outcome.json").write_text(json.dumps(result["metrics"], indent=2))
    plot_gate(result["arrays"], result["metrics"], args.out / "plots")
    print(json.dumps(result["metrics"], indent=2), flush=True)


if __name__ == "__main__":
    main()
